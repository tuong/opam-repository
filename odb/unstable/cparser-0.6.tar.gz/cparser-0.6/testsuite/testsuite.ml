open OUnit

let suite = "test-suite" >::: [
  "test1" >:: (fun () -> "true" @? true);
]

let main = run_test_tt_main suite
