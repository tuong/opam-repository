open Sexplib.Conv
open Sexplib.Sexp

type message =
  | Message of string
  | DefaultMessage
  with sexp

type case =
  FollowCase of string * message
  with sexp

type fragment =
  CodeFragment of string * case list
  with sexp

type handler =
  | Handler of (*opens*)string list * (*func*)string * (*fragments*)fragment list
  with sexp
