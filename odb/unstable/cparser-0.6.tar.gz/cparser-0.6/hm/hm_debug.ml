let debug token lexbuf =
  let open Hm_parser in
  let tok = token lexbuf in
  let str =
    match tok with
    | EOF -> "\n"
    | TK_IDENTIFIER id -> id
    | TK_TVAR id -> "'" ^ id
    | TK_INTEGER d -> string_of_int d
    | TK_STAR -> "*"
    | TK_LBRACK -> "("
    | TK_RBRACK -> ")"
    | TK_ARROW -> "->"
    | TK_EQUALS -> "="
    | KW_LET -> "let"
    | KW_REC -> "rec"
    | KW_IN -> "in"
    | KW_FUN -> "fun"
  in
  Printf.printf "%s " str;
  tok
