type ty =
  | Var of (*name*)string
  | Oper of (*name*)string * (*types*)ty list


let oper name types =
  Oper (name, types)


let new_fun arg result =
  oper "->" [arg; result]


let varname = ref (int_of_char 'a')
let saved_varname = ref 0
let save_var_count () = saved_varname := !varname
let restore_var_count () = varname := !saved_varname

let new_var =
  fun () ->
    let var = char_of_int !varname in
    varname := !varname + 1;
    Var (Char.escaped var)


let rec string_of_type = function
  | Var name ->
      name

  (* print binary operators as "arg1 op arg2" *)
  | Oper (opname, [arg1; arg2]) ->
      "(" ^
      (string_of_type arg1) ^
      " " ^
      opname ^
      " " ^
      (string_of_type arg2) ^
      ")"

  (* other operators are printed as "op arg1 arg2 ..." *)
  | Oper (opname, args) ->
      List.fold_left (fun args arg ->
        args ^ " " ^ (string_of_type arg)
      ) opname args


let print ty = print_string (string_of_type ty)
