open Sexplib.Conv
open Sexplib.Sexp
open Lexing
open Location

type 'a attribute = (string * 'a list) list with sexp

type 'a traits = {
  attrs : 'a attribute;
  pos   : position * position;
  scope : string;
} with sexp

let traits_of_sexp of_sexp sexp = { attrs = []; pos = dummy_pos, dummy_pos; scope = "" }
let sexp_of_traits sexp_of trs = Atom (trs.scope)

let attribute_of_sexp of_sexp sexp = []
let sexp_of_attribute sexp_of attr = List []
