open Sexplib.Sexp
open Sexplib.Conv
open Lexing
open Location

#include "ast.mli"

let die error =
  raise (ASTError error)
