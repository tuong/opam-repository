open Ast
open Attributes


let rec iter_struct symtab = {
  Visit.iter_type = iter_type symtab;
  Visit.iter_expr = iter_expr symtab;
  Visit.iter_stmt = iter_stmt symtab;
  Visit.iter_decl = iter_decl symtab;
}


and iter_decl symtab = function
  (* Enter function and struct/union scopes. *)
  | FunctionDefinition (_, TypedDecl (trs, _, FunctionType _, _, _, _), _)
  | TypedDecl (trs, _, SUEType _, _, _, _) as n ->
      Symtab.enter_scope symtab trs.scope;
      Visit.iter_decl (iter_struct symtab) n;
      Symtab.leave_scope symtab

  | n -> Visit.iter_decl (iter_struct symtab) n


and iter_expr symtab = function
  | n -> Visit.iter_expr (iter_struct symtab) n


and iter_stmt symtab = function
  (* Enter block scope. *)
  | CompoundStatement (trs, _) as n ->
      Symtab.enter_scope symtab trs.scope;
      Visit.iter_stmt (iter_struct symtab) n;
      Symtab.leave_scope symtab

  | n -> Visit.iter_stmt (iter_struct symtab) n


and iter_type symtab = function
  | n -> Visit.iter_type (iter_struct symtab) n
