module type T = sig
  type t

  (* binary operators *)
  val multiply : t -> t -> t
  val divide : t -> t -> t
  val modulo : t -> t -> t
  val add : t -> t -> t
  val subtract : t -> t -> t
  val shift_left : t -> t -> t
  val shift_right : t -> t -> t
  val less : t -> t -> bool
  val greater : t -> t -> bool
  val less_equal : t -> t -> bool
  val greater_equal : t -> t -> bool
  val equal : t -> t -> bool
  val not_equal : t -> t -> bool
  val bitwise_and : t -> t -> t
  val bitwise_or : t -> t -> t
  val bitwise_xor : t -> t -> t
  val logical_and : t -> t -> t
  val logical_or : t -> t -> t

  (* unary operators *)
  val negate : t -> t
  val complement : t -> t
  val increment : t -> t
  val decrement : t -> t
  val logical_not : t -> bool

  (* S-expression I/O *)
  val t_of_sexp : Sexplib.Sexp.t -> t
  val sexp_of_t : t -> Sexplib.Sexp.t

end


module Int : T = struct
  open Big_int

  type t = big_int

  (* binary operators *)
  let multiply = mult_big_int
  let divide = div_big_int
  let modulo = mod_big_int
  let add = add_big_int
  let subtract = sub_big_int
  let shift_left a b = assert false
  let shift_right a b = assert false
  let less a b = assert false
  let greater a b = assert false
  let less_equal a b = assert false
  let greater_equal a b = assert false
  let equal a b = assert false
  let not_equal a b = assert false
  let bitwise_and a b = assert false
  let bitwise_or a b = assert false
  let bitwise_xor a b = assert false
  let logical_and a b = assert false
  let logical_or a b = assert false

  (* unary operators *)
  let negate a = assert false
  let complement a = assert false
  let increment a = assert false
  let decrement a = assert false
  let logical_not b = assert false

  (* S-expression I/O *)
  let t_of_sexp a = assert false
  let sexp_of_t a = assert false
end
