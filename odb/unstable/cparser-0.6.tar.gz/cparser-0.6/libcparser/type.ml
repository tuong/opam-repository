open Ast


(****************************************************************************
 *
 * Helper functions
 *
 ****************************************************************************)


let value_of = function
  | TypedExpression (_, value, _) ->
      value
  | expr -> die (Expression_error ("untyped expression has no value", [expr]))


let type_of = function
  | TypedExpression (ty, _, _) ->
      ty
  | expr -> die (Expression_error ("untyped expression has no type", [expr]))




let is_integral_basic_type = function
  | Bool
  | Char
  | WCharT
  | SChar
  | UChar
  | SShort
  | UShort
  | SInt
  | UInt
  | SLong
  | ULong
  | SIntN _
  | UIntN _ -> true
  | _ -> false


let is_floating_basic_type = function
  | Float
  | Double
  | DecimalN _
  | FloatN _ -> true
  | _ -> false


let is_arithmetic_basic_type bt =
  is_integral_basic_type bt ||
  is_floating_basic_type bt


let is_integral = function
  | BasicType bt -> is_integral_basic_type bt
  | _ -> false


let is_floating = function
  | BasicType bt -> is_floating_basic_type bt
  | _ -> false


let is_arithmetic = function
  | BasicType bt -> is_arithmetic_basic_type bt
  | _ -> false


let is_pointer = function
  | PointerType _ -> true
  | _ -> false


let is_complete a = (*TODO*) true


let rec alignof = function
  | ArrayType (_, base) ->
      alignof base

  | BasicType bt ->
      begin match bt with
      (* Integral types. *)
      | Bool
      | Char
      | SChar
      | UChar -> 1
      | SShort
      | UShort -> Platform.alignof_short
      | SInt
      | UInt -> Platform.alignof_int
      | SLong
      | ULong -> Platform.alignof_long
      | SLongLong
      | ULongLong -> Platform.alignof_long_long

      (* Floating point types. *)
      | Float -> Platform.alignof_float
      | Double -> Platform.alignof_double
      | LongDouble -> Platform.alignof_long_double

      (* XXX: assumes alignment = size for sized types *)

      (* Sized floating point types. *)
      | FloatN bits
      | DecimalN bits

      (* Sized integral types. *)
      | SIntN bits
      | UIntN bits ->
          let bits =
            let rest = bits mod Platform.char_bit in
            if rest = 0 then
              bits
            else
              bits + (Platform.char_bit - rest)
          in
          bits / Platform.char_bit

      (* Other built-in types *)
      | WCharT -> alignof (Platform.wchar_t)
      | VaList -> Platform.alignof_object_pointer (* FIXME: wrong! *)
      | Ellipsis -> die (Type_error ("variadic type `...' has no alignment", []))
      | Void -> die (Type_error ("cannot compute alignment of `void' type", []))
      end

  | PointerType (FunctionType _) -> Platform.alignof_function_pointer
  | PointerType _ -> Platform.alignof_object_pointer

  | SUEType (_, _, _, _::_) as ty ->
      let members = Sue.member_types ty in
      ExList.max (List.map alignof members)

  | ty -> die (Type_error ("cannot compute alignment of type", [ty]))


let rec sizeof = function
  | ArrayType (Some arity, base) ->
      Constant.to_int (value_of arity) * sizeof base

  | BasicType bt ->
      begin match bt with
      (* Integral types. *)
      | Bool
      | Char
      | SChar
      | UChar -> 1
      | SShort
      | UShort -> Platform.sizeof_short
      | SInt
      | UInt -> Platform.sizeof_int
      | SLong
      | ULong -> Platform.sizeof_long
      | SLongLong
      | ULongLong -> Platform.sizeof_long_long

      (* Floating point types. *)
      | Float -> Platform.sizeof_float
      | Double -> Platform.sizeof_double
      | LongDouble -> Platform.sizeof_long_double

      (* Sized floating point types. *)
      | FloatN bits
      | DecimalN bits

      (* Sized integral types. *)
      | SIntN bits
      | UIntN bits ->
          let bits =
            let rest = bits mod Platform.char_bit in
            if rest = 0 then
              bits
            else
              bits + (Platform.char_bit - rest)
          in
          bits / Platform.char_bit

      (* Other built-in types *)
      | WCharT -> sizeof (Platform.wchar_t)
      | VaList -> Platform.sizeof_object_pointer (* FIXME: wrong! *)
      | Ellipsis -> die (Type_error ("variadic type `...' has no size", []))
      | Void -> die (Type_error ("cannot compute size of `void' type", []))
      end

  | PointerType (FunctionType _) -> Platform.sizeof_function_pointer
  | PointerType _ -> Platform.sizeof_object_pointer

  | SUEType (_, SUE_Union, _, _::_) as ty ->
      let members = Sue.member_types ty in
      ExList.max (List.map sizeof members)

  | SUEType (_, SUE_Struct, _, _::_) as ty ->
      let members = Sue.member_types ty in
      ExList.sum (List.map sizeof members)

  | ty -> die (Type_error ("cannot compute size of type", [ty]))


let rec resolve symtab =
  let resolve ty = resolve symtab ty in function
  | TypeofExpr (expr) -> resolve (type_of expr)
  | TypeofType (ty) -> resolve ty
  | BasicType _ as ty -> ty
  | ArrayType (arity, base) -> ArrayType (arity, resolve base)
  | PointerType (base) -> PointerType (resolve base)
  | QualifiedType (tqs, base) -> QualifiedType (tqs, resolve base)
  | TypedefType (name) ->
      let typedef = Symtab.lookup symtab name Symtab.Ordinary in
      resolve (Decls.decl_type typedef)
  | FunctionType (retty, params) ->
      FunctionType (resolve retty, List.map (resolve_decl symtab) params)
  | ty -> die (Type_error ("cannot resolve type", [ty]))

and resolve_decl symtab = function
  | TypedDecl (trs, sc, ty, untyped, asm, init) ->
      TypedDecl (trs, sc, resolve symtab ty, untyped, asm, init)
  | decl -> die (Declaration_error ("cannot resolve declaration type", [decl]))


let rec is_lvalue_ty modifiablep = function
  | QualifiedType (tqs, _) when modifiablep && List.mem TQ_Const tqs -> false

  | QualifiedType (_, base) -> is_lvalue_ty modifiablep base

  | BasicType _ -> true
  | PointerType _ -> true
  | SUEType _ -> true

  | ArrayType _ -> false
  | FunctionType _ -> false

  | TypeofExpr _
  | TypeofType _
  | TypedefType _ as ty -> die (Type_error ("is_lvalue_ty expects resolved type", [ty]))

  | ty -> die (Type_error ("unhandled type in is_lvalue_ty", [ty]))


let rec is_lvalue modifiablep = function
  (* test first for modifiability, if required by caller *)
  | TypedExpression (ty, _, expr) -> is_lvalue_ty modifiablep ty && is_lvalue modifiablep expr

  (* *p is an lvalue. *)
  | UnaryExpression (_, OP_Dereference, _)
  (* a[i] is *(a + i), thus an lvalue. *)
  | ArrayAccess _
  (* Whether the identifier is an lvalue is known from its type. *)
  | Identifier _ -> true

  | NumberLiteral _ -> false

  | decl -> die (Expression_error ("unhandled in is_lvalue", [decl]))
  (*| QualifiedType (tqs, _) when modifiablep && List.mem TQ_Const tqs ->*)
      (*false*)

  (*| QualifiedType (_, base) -> is_lvalue modifiablep base*)


let is_modifiable_lvalue = is_lvalue true
let is_lvalue = is_lvalue false
