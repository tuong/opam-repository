let of_char c =
  let s = " " in
  s.[0] <- c;
  s


let fold_left f a s =
  let rec fold n f a s =
    if n = String.length s then
      a
    else
      fold (n + 1) f (f a s.[n]) s
  in
  fold 0 f a s


let rec nsplit s sep =
  assert (String.length sep = 1);
  try
    let pos = String.index s sep.[0] in
    String.sub s 0 pos :: nsplit (String.sub s (pos + 1) (String.length s - pos - 1)) sep
  with Not_found ->
    [s]
