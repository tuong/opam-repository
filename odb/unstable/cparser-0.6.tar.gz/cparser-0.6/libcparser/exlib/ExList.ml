let max lst =
  List.fold_left (fun a b -> if b > a then b else a) (List.hd lst) (List.tl lst)

let sum lst =
  List.fold_left (fun a b -> a + b) (List.hd lst) (List.tl lst)
