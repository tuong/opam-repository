type t =
  S of string


let adopt s = S s
let to_string (S s) = s

let length (S s) = String.length s
