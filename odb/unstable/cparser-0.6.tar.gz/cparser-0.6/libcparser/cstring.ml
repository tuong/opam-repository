let parse strlist =
  let length =
    List.fold_left (fun len str ->
      len + (String.length str)
    ) 0 strlist
  in
  let buf = Buffer.create length in

  List.iter (fun str ->
    let start = String.index str '"' + 1 in
    let str = String.sub str start (String.length str - start - 1) in

    ignore (ExString.fold_left (fun escape c ->
      match c with
      | '\\' when not escape -> true
      | '\\' -> Buffer.add_char buf '\\'; false

      | 'n' when escape -> Buffer.add_char buf '\n'; false
      | 't' when escape -> Buffer.add_char buf '\t'; false

      | c -> Buffer.add_char buf c; false
    ) false str)

  ) strlist;

  Buffer.contents buf
