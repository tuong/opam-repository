open Ast


let opt fn = function
  | None -> None
  | Some node -> Some (fn node)


let normalise_unit =
  let anonymous prefix =
    let counter = ref 0 in
    let prefix = "__anon_" ^ prefix in
    function () ->
      counter := !counter + 1;
      prefix ^ (string_of_int !counter)
  in

  let anon_sue = anonymous "sue" in
  let anon_id  = anonymous "id" in

  let anon_decl () = IdentifierDeclarator (Traits.empty, anon_id ()) in


  let rec normalise_struct = let open Visit in {
    map_struct with
    map_type = normalise_type;
    map_decl = normalise_decl;
  }


  and normalise_decl = function
    | IdentifierDeclarator (trs, "") ->
        IdentifierDeclarator (trs, anon_id ())
    | TypedDecl (trs, ([SC_Typedef] as sc), (SUEType _ as ty), Nothing, asm, init) ->
        normalise_decl (TypedDecl (trs, sc, ty, anon_decl (), asm, init))
    | StructDeclarator (trs, TypedDecl (dtrs, sc, ty, Nothing, asm, init), bitfield) ->
        normalise_decl (StructDeclarator (trs, TypedDecl (dtrs, sc, ty, anon_decl (), asm, init), bitfield))
    (*
    | FunctionDefinition (trs, (TypedDecl (_, _, _, untyped, _, _) as decl), CompoundStatement (btrs, body)) ->
        let make_literal name =
          let code = "char *" ^ name ^ " = \"" ^ Decls.decl_name untyped ^ "\";" in
          let decl = Parse_util.decl_of_string code in
          DeclarationStatement (decl)
        in

        let n = FunctionDefinition (trs, decl, CompoundStatement (btrs, make_literal "__PRETTY_FUNCTION__" :: body)) in

        Visit.map_decl normalise_struct n
    *)

    | n -> Visit.map_decl normalise_struct n


  and normalise_type = function
    | PartialBasicType [BT_Default] ->
        BasicType SInt

    | PartialBasicType bts ->
        BasicType (Basic_type.of_list bts)

    (* XXX: not good
    | SUEType (attrs, kind, tag, [Nothing]) ->
        let single_char_decl =
          DeclaringList (Traits.empty, [
            StructDeclarator (Traits.empty,
              TypedDecl (Traits.empty,
                [], (* no storage classes *)
                BasicType Char,
                IdentifierDeclarator (Traits.empty, anon_id ()),
                Nothing, (* no asm *)
                None (* no initialiser *)
              ),
            None (* no bitfield *)
            )
          ])
        in
        normalise_type (SUEType (attrs, kind, tag, [single_char_decl]))
    *)

    | SUEType (attrs, kind, "", members) ->
        normalise_type (SUEType (attrs, kind, anon_sue (), members))

    | ty -> Visit.map_type normalise_struct ty


  in normalise_decl
