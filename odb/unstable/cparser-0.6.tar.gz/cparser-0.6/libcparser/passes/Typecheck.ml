open Ast
open Big_int
open Attributes


let value_of = Type.value_of
let type_of = Type.type_of


(****************************************************************************
 *
 * Functions with too much logic to write in the match statements below.
 *
 ****************************************************************************)


let resolve_type symtab = function
  | TypedExpression (ty, value, expr) ->
      TypedExpression (Type.resolve symtab ty, value, expr)
  | expr -> die (Expression_error (",,", [expr]))


let check_assignment op lhs rhs =
  let ltype = type_of lhs in
  let rtype = type_of rhs in

  if not (Type.is_modifiable_lvalue lhs) then
    die (Expression_error ("left operand must be modifiable lvalue", [lhs]));
  let rhs =
    match op with
    | OP_AddAssign
    | OP_SubtractAssign
      when Type.is_pointer ltype
        && Type.is_integral rtype ->
          if not (Type.is_complete (Types.pointer_base ltype)) then
            die (Expression_error ("cannot perform pointer arithmetic on incomplete type", [lhs]));
          rhs
    | _ ->
        Conversions.assignment rhs ltype
  in
  (* The type of the expression is the type of the LHS.
   * The value is unknown, even if the RHS is known,
   * since the LHS is non-constant. *)
  lhs, rhs, ltype, Constant.NonConst

let check_arithmetic op lhs rhs =
  (* Usual unary conversions for ltype and rtype *)
  let lhs = Conversions.unary lhs in
  let rhs = Conversions.unary rhs in
  (* Usual binary conversions unless op is a shift operator *)
  let lhs, rhs =
    match op with
    | OP_ShiftLeft
    | OP_ShiftRight ->
        lhs, rhs
    | _ -> Conversions.binary lhs rhs
  in

  let ltype = type_of lhs in
  let rtype = type_of rhs in

  (* Canonicalise pointer arithmetic expressions: handle int+ptr as ptr+int. *)
  let ltype, lhs, rtype, rhs =
    match op with
    | OP_Add when Type.is_integral ltype && Type.is_pointer rtype ->
        rtype, rhs, ltype, lhs
    | _ ->
        ltype, lhs, rtype, rhs
  in


  (* Check compatibility in arithmetic. *)
  let ok, msg =
    match op with
    | OP_Add ->
        (* Either both operands should have numeric types or one is pointer
         * and the other is integral. *)
        let ok =
          Type.is_arithmetic ltype && Type.is_arithmetic rtype ||
          Type.is_pointer ltype && Type.is_integral rtype
        in
        if not ok then
          false, "operands must have arithmetic type or ptr/int"
        else
          let ok =
            not (Type.is_pointer ltype) || Type.is_complete ltype
          in
          ok, "pointed-to type is incomplete"

    | OP_Subtract ->
        (* Allow num-num, ptr-int and ptr-ptr. *)
        let ok =
          Type.is_arithmetic ltype && Type.is_arithmetic rtype ||
          Type.is_pointer ltype && Type.is_integral rtype ||
          Type.is_pointer ltype && Type.is_pointer rtype
        in
        ok, "operands have incompatible types"

    (* Numeric operators. *)
    | OP_Divide
    | OP_Multiply ->
        let ok =
          Type.is_arithmetic ltype && Type.is_arithmetic rtype
        in
        ok, "operands must have arithmetic type"

    (* Integral operators. *)
    | OP_Modulo
    | OP_BitwiseAnd
    | OP_BitwiseOr
    | OP_BitwiseXor
    | OP_ShiftLeft
    | OP_ShiftRight ->
        let ok =
          Type.is_integral ltype && Type.is_integral rtype
        in
        ok, "operands must have integral type"

    | OP_LogicalAnd
    | OP_LogicalOr ->
        let ok =
          true (* TODO: check conversion to bool *)
        in
        ok, "operands must be convertible to bool"

    | _ ->
        false, "unhandled operator"
  in
  if not ok then
    die (Expression_error (msg ^ " in binary operator `" ^ (Token.string_of_binop op) ^ "'", [lhs; rhs]));


  (* Perform arithmetic. *)
  let exprtype, exprval =
    match op with
    | OP_Add ->
        if Type.is_pointer ltype then
          (* At this point, we don't know the value of pointer arithmetic. *)
          ltype, Constant.NonConst
        else
          let lval = value_of lhs in
          let rval = value_of rhs in

          (* Expression type is that of the left hand side (after conversions and canonicalisation). *)
          ltype, Const_eval.eval_arithmetic op lval rval

    | OP_Subtract ->
        if Type.is_pointer rtype then
          (* At this point, we don't know the value of pointer arithmetic. *)
          Platform.ptrdiff_t, Constant.NonConst
        else
          let lval = value_of lhs in
          let rval = value_of rhs in
          ltype, Const_eval.eval_arithmetic op lval rval

    | OP_BitwiseAnd
    | OP_BitwiseOr
    | OP_BitwiseXor
    | OP_Divide
    | OP_Modulo
    | OP_Multiply
    | OP_ShiftLeft
    | OP_ShiftRight ->
        let lval = value_of lhs in
        let rval = value_of rhs in
        ltype, Const_eval.eval_arithmetic op lval rval

    | OP_LogicalAnd
    | OP_LogicalOr ->
        let lval = value_of lhs in
        let rval = value_of rhs in
        PartialBasicType [BT_Bool], Const_eval.eval_arithmetic op lval rval

    | _ -> die (Unimplemented "check_arithmetic")
  in

  lhs, rhs, exprtype, exprval



(****************************************************************************
 *
 * Main type-check visitor.
 *
 ****************************************************************************)


let rec tcheck_struct symtab = let open Visit in {
  map_type = tcheck_type symtab;
  map_expr = tcheck_expr symtab;
  map_stmt = tcheck_stmt symtab;
  map_decl = tcheck_decl symtab;
}


and tcheck_decl symtab = function
  | TypedDecl (trs, _, SUEType (_, suekind, tag, members), untyped, _, _) as decl ->
      if suekind <> SUE_Enum then
        Symtab.enter_scope symtab trs.scope;

      let decl = Visit.map_decl (tcheck_struct symtab) decl in

      if suekind <> SUE_Enum then
        Symtab.leave_scope symtab;

      begin match members with
      | [] -> () (* We did not get any additional information on SUE declarations. *)
      | _ -> Symtab.replace symtab tag Symtab.Tag decl
      end;

      begin match untyped with
      | Nothing ->
          ()
      | untyped ->
          Symtab.replace symtab (Decls.decl_name untyped) Symtab.Ordinary decl
      end;
      decl

  | TypedDecl (_, sc, _, untyped, _, _) as decl ->
      let decl = Visit.map_decl (tcheck_struct symtab) decl in
      Symtab.replace symtab (Decls.decl_name untyped) Symtab.Ordinary decl;
      decl

  | n -> Visit.map_decl (tcheck_struct symtab) n


and tcheck_stmt symtab = function
  | CompoundStatement (trs, _) as n ->
      Symtab.enter_scope symtab trs.scope;
      let n = Visit.map_stmt (tcheck_struct symtab) n in
      Symtab.leave_scope symtab;
      n

  | n -> die (Statement_error ("unhandled statement in type check", [n]))


and tcheck_expr symtab untyped =
  match Visit.map_expr (tcheck_struct symtab) untyped with
  | NumberLiteral (_, (LIT_Float | LIT_HexFloat as kind), str, suffix) as lit ->
      TypedExpression (Tcheck.float_type suffix, Const_eval.parse_float kind str, lit)

  | NumberLiteral (_, (LIT_Hex | LIT_Oct | LIT_Bin | LIT_Dec as kind), str, suffix) as lit ->
      TypedExpression (Tcheck.int_type suffix, Const_eval.parse_int kind str, lit)

  | StringLiteral (_, kind, strlist) as lit ->
      let chars = Const_eval.parse_string_literal strlist in
      TypedExpression (Tcheck.string_type kind chars, Const_eval.make_string kind chars, lit)

  | BinaryExpression (trs, op, lhs, rhs) as expr ->
      let lhs = resolve_type symtab lhs in
      let rhs = resolve_type symtab rhs in

      let lhs, rhs, exprtype, exprval =
        if Operator.is_assignment op then check_assignment op lhs rhs
        else if Operator.is_arithmetic op then check_arithmetic op lhs rhs
        else die (Expression_error ("unhandled binary operator", [expr]))
      in

      TypedExpression (exprtype, exprval, BinaryExpression (trs, op, lhs, rhs))

  | Cast (_, ty, expr) as cast ->
      TypedExpression (ty, value_of expr, cast)

  | SizeofExpr (_, expr) as sizeof ->
      TypedExpression (Platform.size_t, Constant.of_int (Type.sizeof (type_of expr)), sizeof)

  | SizeofType (_, ty) as sizeof ->
      TypedExpression (Platform.size_t, Constant.of_int (Type.sizeof ty), sizeof)

  | AlignofExpr (_, expr) as alignof ->
      TypedExpression (Platform.size_t, Constant.of_int (Type.alignof (type_of expr)), alignof)

  | AlignofType (_, ty) as alignof ->
      TypedExpression (Platform.size_t, Constant.of_int (Type.alignof ty), alignof)

  | ArrayAccess (trs, expr, index) ->
      let expr = Conversions.unary expr in
      TypedExpression (Types.pointer_base (type_of expr), Constant.NonConst, ArrayAccess (trs, expr, index))

  | Identifier (_, id) as n ->
      let ty, value =
        match Symtab.lookup symtab id Symtab.Ordinary with
        | Enumerator (_, _, Some (TypedExpression (ty, value, _))) -> ty, value
        | decl -> Decls.decl_type decl, Constant.NonConst
      in
      TypedExpression (ty, value, n)

  | n -> die (Expression_error ("unhandled expression in type check", [n]))


and tcheck_type symtab untyped =
  match Visit.map_type (tcheck_struct symtab) untyped with
  | SUEType (attrs, SUE_Enum, tag, members) ->
      let _, members =
        List.fold_left (fun (value, members) enum ->
          let value, enum, name =
            match enum with
            | Enumerator (trs, name, None) ->
                succ_big_int value, Enumerator (trs, name, Some (Const_eval.make_int value)), name
            | Enumerator (_, name, Some value) as enum ->
                succ_big_int (Constant.to_big_int (value_of value)), enum, name
            | decl -> die (Declaration_error ("invalid declaration in enum", [decl]))
          in
          Symtab.replace symtab name Symtab.Ordinary enum;
          value, enum :: members
        ) (zero_big_int, []) members
      in
      SUEType (attrs, SUE_Enum, tag, List.rev members)

  | n -> n


let tcheck_unit = tcheck_decl
(*let tcheck_unit a b = b*)
