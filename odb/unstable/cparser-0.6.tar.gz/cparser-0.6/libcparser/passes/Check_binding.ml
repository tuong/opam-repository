open Ast
open Attributes


let rec check_struct symtab = let open Visit in {
  iter_type = check_type symtab;
  iter_expr = check_expr symtab;
  iter_stmt = check_stmt symtab;
  iter_decl = check_decl symtab;
}


and check_decl symtab = function
  (* Enter function and struct/union scopes. *)
  | FunctionDefinition (_, TypedDecl (trs, _, FunctionType _, _, _, _), _)
  | TypedDecl (trs, _, SUEType _, _, _, _) as n ->
      Symtab.enter_scope symtab trs.scope;
      Visit.iter_decl (check_struct symtab) n;
      Symtab.leave_scope symtab

  | n -> Visit.iter_decl (check_struct symtab) n


and check_expr symtab = function
  | Identifier (_, id) as n ->
      let is_builtin id =
        let prefix = "__builtin_" in
        let prefix_len = String.length prefix in
        String.length id > prefix_len &&
        String.sub id 0 prefix_len = prefix
      in

      if not (is_builtin id) then
        begin try
          ignore (Symtab.lookup symtab id Symtab.Ordinary)
        with Not_found ->
          die (Expression_error ("identifier not declared in this scope (ISO 6.2.1p2)", [n]))
        end

  | n -> Visit.iter_expr (check_struct symtab) n


and check_stmt symtab = function
  (* Enter block scope. *)
  | CompoundStatement (trs, _) as n ->
      Symtab.enter_scope symtab trs.scope;
      Visit.iter_stmt (check_struct symtab) n;
      Symtab.leave_scope symtab

  | n -> Visit.iter_stmt (check_struct symtab) n


and check_type symtab = function
  | TypedefType (id) ->
      (* TODO: there are some built-in typedefs we should enter into the symbol table *)
      ignore (Symtab.lookup symtab id Symtab.Ordinary)
  | n -> Visit.iter_type (check_struct symtab) n


let check_unit = check_decl
