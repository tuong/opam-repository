open Ast
open Attributes


type symtype =
  (* Can occur multiple times. *)
  | Declaration
  (* Can occur only once. *)
  | Definition


let opt fn data = function
  | None -> data
  | Some node -> fn data node


let sym scope name kind decl = let open Symtab in {
  scope = scope;
  name = name;
  namespace = kind;
  decl = decl;
}


let rec collect_struct scope = let open Visit in {
  fold_type = collect_type scope;
  fold_expr = collect_expr scope;
  fold_stmt = collect_stmt scope;
  fold_decl = collect_decl scope;
}


and collect_decl scope syms = function
  | Nothing
  | IdentifierDeclarator _
  | DeclaringList _
  | AsmSpecifier _
  | TranslationUnit _ as n ->
      Visit.fold_decl (collect_struct scope) syms n

  | Enumerator (_, id, expr) as enum ->
      (* Handle enumerators as (constant) variable definitions. *)
      let syms = (sym scope id Symtab.Ordinary enum, Definition) :: syms in

      opt (Visit.fold_expr (collect_struct scope)) syms expr

  | StructDeclarator (_, TypedDecl (_, _, ty, untyped, _, init), _) as decl ->
      let name = Decls.decl_name untyped in
      let syms = (sym scope name Symtab.Member decl, Definition) :: syms in

      let syms = Visit.fold_type (collect_struct scope) syms ty in
      opt (Visit.fold_expr (collect_struct scope)) syms init

  | FunctionDefinition (_, TypedDecl (trs, _, FunctionType (retty, params), untyped, _, _), body) as defn ->
      let name = Decls.decl_name untyped in
      let syms = (sym scope name Symtab.Ordinary defn, Definition) :: syms in

      let scope = trs.scope in
      (* Put parameter declarations into the same scope as the function body *)
      let syms = List.fold_left (collect_decl scope) syms params in
      (* Directly visit the body's statements, ignoring its scope, as it
       * should be the same scope as the parameter declarations. *)
      Visit.fold_stmt (collect_struct scope) syms body

  (* For function declarations, ignore the parameters, just record the decl itself. *)
  | TypedDecl (trs, _, FunctionType _, untyped, _, _) as decl ->
      let name = Decls.decl_name untyped in
      (sym scope name Symtab.Ordinary decl, Declaration) :: syms

  | TypedDecl (trs, sc, SUEType (_, kind, tag, members), untyped, _, _) as decl ->
      let syms =
        match untyped with
        | Nothing ->
            syms
        | untyped ->
            let name = Decls.decl_name untyped in
            let kind = if List.mem SC_Extern sc then Declaration else Definition in
            (sym scope name Symtab.Ordinary decl, kind) :: syms
      in

      let syms =
        match members with
        | [] ->
            (sym scope tag Symtab.Tag decl, Declaration) :: syms
        | _ ->
            (sym scope tag Symtab.Tag decl, Definition) :: syms
      in

      let scope =
        match kind with
        | SUE_Union
        | SUE_Struct -> trs.scope
        (* Don't open a new scope for enums *)
        | SUE_Enum -> scope
      in

      Visit.fold_decl (collect_struct scope) syms decl

  (* `void' and `...' parameter *)
  | TypedDecl (_, _, BasicType (Ellipsis | Void), Nothing, _, _) as decl ->
      Visit.fold_decl (collect_struct scope) syms decl

  | TypedDecl (_, sc, _, untyped, _, _) as decl ->
      let name = Decls.decl_name untyped in
      let kind = if List.mem SC_Extern sc then Declaration else Definition in
      let syms = (sym scope name Symtab.Ordinary decl, kind) :: syms in
      Visit.fold_decl (collect_struct scope) syms decl

  | WildcardDecl _
  | ToplevelAsm _
  | PreprocessorDirective _ ->
      syms

  | n -> die (Declaration_error ("invalid declaration while building symbol table", [n]))


and collect_expr scope syms = function
  | n -> Visit.fold_expr (collect_struct scope) syms n


and collect_stmt scope syms = function
  | CompoundStatement (trs, _) as n ->
      Visit.fold_stmt (collect_struct trs.scope) syms n;
  | n -> Visit.fold_stmt (collect_struct scope) syms n


and collect_type scope syms = function
  (* Ignore parameter names in non-function declarators containing a function type. *)
  | FunctionType (retty, params) ->
      let syms = collect_type scope syms retty in
      List.fold_left (Visit.fold_decl (collect_struct scope)) syms params
  | n -> Visit.fold_type (collect_struct scope) syms n


let rec compatible decl1 decl2 =
  match decl1, decl2 with
  | TypedDecl (_, _, ty1, _, _, _), TypedDecl (_, _, ty2, _, _, _) ->
      Traits.clear_deep_type ty1 = Traits.clear_deep_type ty2
  | FunctionDefinition (_, decl1, _), decl2
  | decl1, FunctionDefinition (_, decl2, _) ->
      compatible decl1 decl2
  | _ -> false


let update_symtab symtab sym kind =
  let symtype = sym.Symtab.namespace in
  let symdecl = sym.Symtab.decl in

  match symtype with
  | Symtab.Member
  | Symtab.Ordinary ->
      let rec check_conflict = function

        (* Function declaration. *)
        | TypedDecl (_, _, FunctionType _, _, _, _) as fdecl ->
            if not (compatible fdecl symdecl) then
              die (Declaration_error ("incompatible function redeclaration", [fdecl; symdecl]));
            Symtab.replace_in_scope symtab sym

        (* Variable declaration. *)
        | TypedDecl (_, sclasses, _, _, _, _) as vdecl when List.mem SC_Extern sclasses ->
            if not (compatible vdecl symdecl) then
              die (Declaration_error ("incompatible variable redeclaration", [vdecl; symdecl]));
            Symtab.replace_in_scope symtab sym

        (* Function definition. *)
        | FunctionDefinition (_, fdecl, _) as fdefn ->
            if kind = Definition then
              die (Declaration_error ("redefinition of function", [fdefn; symdecl]));

            if not (compatible fdecl symdecl) then
              die (Declaration_error ("function definition incompatible with its declaration", [fdecl; symdecl]));

        (* Variable definition. *)
        | TypedDecl _ as vdefn ->
            if kind = Definition then
              die (Declaration_error ("redefinition of variable", [vdefn; symdecl]));

            if not (compatible vdefn symdecl) then
              die (Declaration_error ("variable definition incompatible with its declaration", [vdefn; symdecl]));

        (* Struct member. *)
        | StructDeclarator (_, decl, _) ->
            check_conflict decl

        | decl -> die (Declaration_error ("Ordinary or Member", [decl]))

      in
      check_conflict

  | Symtab.Tag ->
      let rec check_conflict = function

        | TypedDecl (_, _, SUEType (_, suekind, _, members), _, _, _) as sdecl ->
            if suekind <> Sue.kind_of (Decls.decl_type symdecl) then
              die (Declaration_error ("tag defined with different kinds", [sdecl; symdecl]));

            begin match members with
            (* SUE declaration. *)
            | [] -> ()
            (* SUE definition. *)
            | _ ->
                if not (Sue.is_decl (Decls.decl_type symdecl)) then
                  die (Declaration_error ("struct/union/enum type redefined", [sdecl; symdecl]));
            end

        | decl -> die (Declaration_error ("Tag", [decl]))

      in
      check_conflict

  | Symtab.Label ->
      fun x -> ()


let global_syms = [
  (sym "global" "__PRETTY_FUNCTION__" Symtab.Ordinary Nothing, Declaration)
]


let collect symtab tu =
  let syms = List.rev (collect_decl "global" global_syms tu) in

  List.iter (fun (sym, kind) ->

    try
      let open Symtab in
      let existing = Symtab.lookup_in_scope symtab sym.scope sym.name sym.namespace in
      update_symtab symtab sym kind existing
    with
    | Not_found ->
        Symtab.insert_into_scope symtab sym
    | ASTError (Declaration_error (msg, [a; b])) as e ->
        let decl_of_fdecl = function
          | FunctionDefinition (_, decl, _) -> decl
          | decl -> decl
        in

        let open Lexing in
        let pos, _ = Traits.pos_of_decl b in
        if pos.pos_fname.[0] = '.' then begin
          let pr decl =
            let pos, _ = Traits.pos_of_decl decl in
            Printf.printf "    %s:%d: %s\n" pos.pos_fname pos.pos_lnum (Codegen.code_of_decl (Traits.clear_deep_decl (decl_of_fdecl decl)));
          in
          Printf.printf "\n%s\n" msg;
          Printf.printf "  this declaration:\n";
          pr b;
          Printf.printf "  previous declaration:\n";
          pr a;
        end

  ) syms
