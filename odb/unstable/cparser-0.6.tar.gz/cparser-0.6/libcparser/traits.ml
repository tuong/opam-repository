open Ast
open Attributes

let empty = { attrs = []; pos = Lexing.dummy_pos, Lexing.dummy_pos; scope = "" }


(* {{{ *)
let traits_of_expr = function
  (* Wildcards *)
  | WildcardExpr (trs, _)

  (* Expression *)
  | TernaryExpression (trs, _, _, _, _)
  | BinaryExpression (trs, _, _, _)
  | UnaryExpression (trs, _, _)
  | FunctionCall (trs, _, _)
  | ArrayAccess (trs, _, _)
  | MemberAccess (trs, _, _)
  | PointerAccess (trs, _, _)
  | SizeofExpr (trs, _)
  | SizeofType (trs, _)
  | AlignofExpr (trs, _)
  | AlignofType (trs, _)
  | Offsetof (trs, _, _)
  | TypesCompatibleP (trs, _, _)
  | VaArg (trs, _, _)

  (* Primary expression *)
  | Identifier (trs, _)
  | NumberLiteral (trs, _, _, _)
  | CharLiteral (trs, _, _)
  | StringLiteral (trs, _, _)
  | BraceExpression (trs, _)

  (* Cast expression *)
  | CompoundLiteral (trs, _, _)
  | Cast (trs, _, _)

  (* Initialisers *)
  | ArrayLabelledInitialiser (trs, _, _)
  | DesignatedInitialiser (trs, _, _)
  | InitialiserList (trs, _) -> trs

  (* Expression with type information *)
  | TypedExpression _

  | MemberDesignator _ -> empty


let traits_of_stmt = function
  | DeclarationStatement _
  | Nop -> empty

  (* Statements *)
  | CompoundStatement (trs, _)
  | ExpressionStatement (trs, _)

  (* Labelled statements *)
  | LabelledStatement (trs, _, _)
  | LocalLabel (trs, _)
  | CaseStatement (trs, _)
  | DefaultStatement (trs)

  (* Selection statements *)
  | IfStatement (trs, _, _, _)
  | SwitchStatement (trs, _, _)

  (* Iteration statements *)
  | WhileStatement (trs, _, _)
  | DoWhileStatement (trs, _, _)
  | ForStatement (trs, _, _, _, _)

  (* Jump statements *)
  | GotoStatement (trs, _)
  | ContinueStatement (trs)
  | BreakStatement (trs)
  | ReturnStatement (trs, _)

  (* GCC asm statement *)
  | AsmStatement (trs, _, _, _, _, _, _) -> trs


let traits_of_type = function
  | NoType -> empty

  (* Wildcards *)
  | WildcardType (trs, _) -> trs

  (* Types *)
  | PartialBasicType _
  | BasicType _
  | QualifiedType _
  | PointerType _
  | SUEType _
  | TypedefType _
  | ArrayType _
  | FunctionType _
  | TypeofType _
  | TypeofExpr _ -> empty


let traits_of_decl = function
  | Nothing
  | TranslationUnit (_) -> empty

  (* Wildcards *)
  | WildcardDecl (trs, _)

  (* #include etc. *)
  | PreprocessorDirective (trs, _)

  (* Syntax errors *)
  | SyntaxError (trs, _, _)

  (* Generic nodes *)
  | AsmSpecifier (trs, _)
  | FunctionDefinition (trs, _, _)
  | IdentifierDeclarator (trs, _)
  | StructDeclarator (trs, _, _)
  | TypedDecl (trs, _, _, _, _, _)
  | DeclaringList (trs, _)

  (* Statements *)
  | ToplevelAsm (trs, _)

  (* Struct/union/enum types *)
  | Enumerator (trs, _, _) -> trs


let rec set_traits_decl trs = function
  | Nothing -> Nothing
  | TranslationUnit (decls) -> TranslationUnit (decls)

  (* Wildcards *)
  | WildcardDecl (trs, wc) -> WildcardDecl (trs, wc)

  (* #include etc. *)
  | PreprocessorDirective (trs, dir) -> PreprocessorDirective (trs, dir)

  (* Syntax errors *)
  | SyntaxError (trs, msg, node) -> SyntaxError (trs, msg, node)

  (* Statements *)
  | ToplevelAsm _ as node -> node

  (* Generic nodes *)
  | AsmSpecifier (trs, reg) -> AsmSpecifier (trs, reg)
  | FunctionDefinition (trs, decl, body) -> FunctionDefinition (trs, decl, body)
  | IdentifierDeclarator (trs, id) -> IdentifierDeclarator (trs, id)
  | StructDeclarator (trs, decl, bitfield) -> StructDeclarator (trs, decl, bitfield)
  | TypedDecl (trs, sclasses, ty, untyped, asm, init) -> TypedDecl (trs, sclasses, ty, untyped, asm, init)
  | DeclaringList (trs, decls) -> DeclaringList (trs, decls)

  (* Struct/union/enum types *)
  | Enumerator (trs, id, value) -> Enumerator (trs, id, value)


let set_traits_expr trs = function
  (* Wildcards *)
  | WildcardExpr (trs, wc) -> WildcardExpr (trs, wc)

  (* Expression with type information *)
  | TypedExpression (ty, value, expr) as node -> node

  (* Expression *)
  | TernaryExpression (trs, op, cond, then_expr, else_expr) -> TernaryExpression (trs, op, cond, then_expr, else_expr)
  | BinaryExpression (trs, op, lhs, rhs) -> BinaryExpression (trs, op, lhs, rhs)
  | UnaryExpression (trs, op, expr) -> UnaryExpression (trs, op, expr)
  | Offsetof (trs, ty, member) -> Offsetof (trs, ty, member)
  | TypesCompatibleP (trs, ty1, ty2) -> TypesCompatibleP (trs, ty1, ty2)
  | VaArg (trs, ap, ty) -> VaArg (trs, ap, ty)
  | FunctionCall (trs, expr, args) -> FunctionCall (trs, expr, args)
  | MemberAccess (trs, expr, member) -> MemberAccess (trs, expr, member)
  | PointerAccess (trs, expr, member) -> PointerAccess (trs, expr, member)
  | ArrayAccess (trs, expr, index) -> ArrayAccess (trs, expr, index)
  | AlignofExpr (trs, expr) -> AlignofExpr (trs, expr)
  | AlignofType (trs, ty) -> AlignofType (trs, ty)
  | SizeofExpr (trs, expr) -> SizeofExpr (trs, expr)
  | SizeofType (trs, ty) -> SizeofType (trs, ty)
  | CompoundLiteral (trs, ty, init) -> CompoundLiteral (trs, ty, init)

  (* Primary expression *)
  | Identifier (trs, id) -> Identifier (trs, id)
  | NumberLiteral (trs, kind, lit, suffix) -> NumberLiteral (trs, kind, lit, suffix)
  | CharLiteral (trs, kind, lit) -> CharLiteral (trs, kind, lit)
  | StringLiteral (trs, kind, lit) -> StringLiteral (trs, kind, lit)
  | BraceExpression (trs, stmt) -> BraceExpression (trs, stmt)

  (* Cast expression *)
  | Cast (trs, ty, expr) -> Cast (trs, ty, expr)

  (* Initialisers *)
  | InitialiserList (trs, inits) -> InitialiserList (trs, inits)
  | MemberDesignator (members) as node -> node
  | ArrayLabelledInitialiser (trs, index, init) -> ArrayLabelledInitialiser (trs, index, init)
  | DesignatedInitialiser (trs, designator, init) -> DesignatedInitialiser (trs, designator, init)


let set_traits_type trs = function
  | NoType

  (* Wildcards *)
  | WildcardType _

  (* Types *)
  | PartialBasicType _
  | BasicType _
  | QualifiedType _
  | PointerType _
  | SUEType _
  | TypedefType _
  | ArrayType _
  | FunctionType _
  | TypeofType _
  | TypeofExpr _ as node -> node


let set_traits_stmt trs = function
  | Nop -> Nop

  (* Statements *)
  | CompoundStatement (trs, stmts) -> CompoundStatement (trs, stmts)
  | ExpressionStatement (trs, expr) -> ExpressionStatement (trs, expr)
  | DeclarationStatement (decl) as node -> node

  (* Labelled statements *)
  | LabelledStatement (trs, label, stmt) -> LabelledStatement (trs, label, stmt)
  | LocalLabel (trs, labels) -> LocalLabel (trs, labels)
  | CaseStatement (trs, expr) -> CaseStatement (trs, expr)
  | DefaultStatement (trs) -> DefaultStatement (trs)

  (* Selection statements *)
  | IfStatement (trs, cond, then_stmt, else_stmt) -> IfStatement (trs, cond, then_stmt, else_stmt)
  | SwitchStatement (trs, expr, cases) -> SwitchStatement (trs, expr, cases)

  (* Iteration statements *)
  | WhileStatement (trs, cond, body) -> WhileStatement (trs, cond, body)
  | DoWhileStatement (trs, body, cond) -> DoWhileStatement (trs, body, cond)
  | ForStatement (trs, init, cond, next, body) -> ForStatement (trs, init, cond, next, body)

  (* Jump statements *)
  | GotoStatement (trs, expr) -> GotoStatement (trs, expr)
  | ContinueStatement (trs) -> ContinueStatement (trs)
  | BreakStatement (trs) -> BreakStatement (trs)
  | ReturnStatement (trs, expr) -> ReturnStatement (trs, expr)

  (* GCC asm statement *)
  | AsmStatement (trs, volatile, code, in_args, out_args, clobber, labels) ->
      AsmStatement (trs, volatile, code, in_args, out_args, clobber, labels)


let opt fn = function
  | None -> None
  | Some node -> Some (fn node)


let rec clear_deep_decl =
  let map = List.map in function
  | Nothing -> Nothing
  | TranslationUnit (decls) -> TranslationUnit (map clear_deep_decl decls)

  (* Wildcards *)
  | WildcardDecl (trs, wc) -> WildcardDecl (empty, wc)

  (* #include etc. *)
  | PreprocessorDirective (trs, dir) -> PreprocessorDirective (empty, dir)

  (* Syntax errors *)
  | SyntaxError (trs, msg, node) -> SyntaxError (empty, msg, clear_deep_decl node)

  (* Statements *)
  | ToplevelAsm _ as node -> node

  (* Generic nodes *)
  | AsmSpecifier (trs, reg) -> AsmSpecifier (empty, reg)
  | FunctionDefinition (trs, decl, body) -> FunctionDefinition (empty, clear_deep_decl decl, clear_deep_stmt body)
  | IdentifierDeclarator (trs, id) -> IdentifierDeclarator (empty, id)
  | StructDeclarator (trs, decl, bitfield) -> StructDeclarator (empty, clear_deep_decl decl, opt clear_deep_expr bitfield)
  | TypedDecl (trs, sclasses, ty, untyped, asm, init) -> TypedDecl (empty, sclasses, clear_deep_type ty, clear_deep_decl untyped, clear_deep_decl asm, opt clear_deep_expr init)
  | DeclaringList (trs, decls) -> DeclaringList (empty, map clear_deep_decl decls)

  (* Struct/union/enum types *)
  | Enumerator (trs, id, value) -> Enumerator (empty, id, opt clear_deep_expr value)


and clear_deep_expr =
  let map = List.map in function
  (* Wildcards *)
  | WildcardExpr (trs, wc) -> WildcardExpr (empty, wc)

  (* Expression with type information *)
  | TypedExpression (ty, value, expr) as node -> node

  (* Expression *)
  | TernaryExpression (trs, op, cond, then_expr, else_expr) -> TernaryExpression (empty, op, clear_deep_expr cond, opt clear_deep_expr then_expr, clear_deep_expr else_expr)
  | BinaryExpression (trs, op, lhs, rhs) -> BinaryExpression (empty, op, clear_deep_expr lhs, clear_deep_expr rhs)
  | UnaryExpression (trs, op, expr) -> UnaryExpression (empty, op, clear_deep_expr expr)
  | Offsetof (trs, ty, member) -> Offsetof (empty, clear_deep_type ty, clear_deep_expr member)
  | TypesCompatibleP (trs, ty1, ty2) -> TypesCompatibleP (empty, clear_deep_type ty1, clear_deep_type ty2)
  | VaArg (trs, ap, ty) -> VaArg (empty, clear_deep_expr ap, clear_deep_type ty)
  | FunctionCall (trs, expr, args) -> FunctionCall (empty, clear_deep_expr expr, map clear_deep_expr args)
  | MemberAccess (trs, expr, member) -> MemberAccess (empty, clear_deep_expr expr, member)
  | PointerAccess (trs, expr, member) -> PointerAccess (empty, clear_deep_expr expr, member)
  | ArrayAccess (trs, expr, index) -> ArrayAccess (empty, clear_deep_expr expr, clear_deep_expr index)
  | AlignofExpr (trs, expr) -> AlignofExpr (empty, clear_deep_expr expr)
  | AlignofType (trs, ty) -> AlignofType (empty, clear_deep_type ty)
  | SizeofExpr (trs, expr) -> SizeofExpr (empty, clear_deep_expr expr)
  | SizeofType (trs, ty) -> SizeofType (empty, clear_deep_type ty)
  | CompoundLiteral (trs, ty, init) -> CompoundLiteral (empty, clear_deep_type ty, clear_deep_expr init)

  (* Primary expression *)
  | Identifier (trs, id) -> Identifier (empty, id)
  | NumberLiteral (trs, kind, lit, suffix) -> NumberLiteral (empty, kind, lit, suffix)
  | CharLiteral (trs, kind, lit) -> CharLiteral (empty, kind, lit)
  | StringLiteral (trs, kind, lit) -> StringLiteral (empty, kind, lit)
  | BraceExpression (trs, stmt) -> BraceExpression (empty, clear_deep_stmt stmt)

  (* Cast expression *)
  | Cast (trs, ty, expr) -> Cast (empty, clear_deep_type ty, clear_deep_expr expr)

  (* Initialisers *)
  | InitialiserList (trs, inits) -> InitialiserList (empty, map clear_deep_expr inits)
  | MemberDesignator (members) as node -> node
  | ArrayLabelledInitialiser (trs, index, init) -> ArrayLabelledInitialiser (empty, clear_deep_expr index, clear_deep_expr init)
  | DesignatedInitialiser (trs, designator, init) -> DesignatedInitialiser (empty, clear_deep_expr designator, clear_deep_expr init)


and clear_deep_type =
  let map = List.map in function
  | NoType -> NoType

  (* Wildcards *)
  | WildcardType (trs, wc) -> WildcardType (empty, wc)

  (* Types *)
  | PartialBasicType (bts) -> PartialBasicType (bts)
  | BasicType (bt) -> BasicType (bt)
  | QualifiedType (tquals, unqual) -> QualifiedType (tquals, clear_deep_type unqual)
  | PointerType (base) -> PointerType (clear_deep_type base)
  | SUEType (attrs, kind, tag, members) -> SUEType (attrs, kind, tag, map clear_deep_decl members)
  | TypedefType (id) -> TypedefType (id)
  | ArrayType (arity, base) -> ArrayType (opt clear_deep_expr arity, clear_deep_type base)
  | FunctionType (rettype, params) -> FunctionType (clear_deep_type rettype, map clear_deep_decl params)
  | TypeofType (ty) -> TypeofType (clear_deep_type ty)
  | TypeofExpr (expr) -> TypeofExpr (clear_deep_expr expr)


and clear_deep_stmt =
  let map = List.map in function
  | Nop -> Nop

  (* Statements *)
  | CompoundStatement (trs, stmts) -> CompoundStatement (empty, map clear_deep_stmt stmts)
  | ExpressionStatement (trs, expr) -> ExpressionStatement (empty, opt clear_deep_expr expr)
  | DeclarationStatement (decl) -> DeclarationStatement (clear_deep_decl decl)

  (* Labelled statements *)
  | LabelledStatement (trs, label, stmt) -> LabelledStatement (empty, label, clear_deep_stmt stmt)
  | LocalLabel (trs, labels) -> LocalLabel (empty, labels)
  | CaseStatement (trs, expr) -> CaseStatement (empty, clear_deep_expr expr)
  | DefaultStatement (trs) -> DefaultStatement (empty)

  (* Selection statements *)
  | IfStatement (trs, cond, then_stmt, else_stmt) -> IfStatement (empty, clear_deep_expr cond, clear_deep_stmt then_stmt, clear_deep_stmt else_stmt)
  | SwitchStatement (trs, expr, cases) -> SwitchStatement (empty, clear_deep_expr expr, clear_deep_stmt cases)

  (* Iteration statements *)
  | WhileStatement (trs, cond, body) -> WhileStatement (empty, clear_deep_expr cond, clear_deep_stmt body)
  | DoWhileStatement (trs, body, cond) -> DoWhileStatement (empty, clear_deep_stmt body, clear_deep_expr cond)
  | ForStatement (trs, init, cond, next, body) -> ForStatement (empty, opt clear_deep_expr init, opt clear_deep_expr cond, opt clear_deep_expr next, clear_deep_stmt body)

  (* Jump statements *)
  | GotoStatement (trs, expr) -> GotoStatement (empty, clear_deep_expr expr)
  | ContinueStatement (trs) -> ContinueStatement (empty)
  | BreakStatement (trs) -> BreakStatement (empty)
  | ReturnStatement (trs, expr) -> ReturnStatement (empty, opt clear_deep_expr expr)

  (* GCC asm statement *)
  | AsmStatement (trs, volatile, code, in_args, out_args, clobber, labels) ->
      let clear (trs, constr, expr) =
        (trs, constr, clear_deep_expr expr)
      in
      AsmStatement (empty, volatile, code, map clear in_args, map clear out_args, clobber, labels)
(* }}} *)


let copy_pos node =
  let trs = traits_of_decl node in
  { empty with pos = trs.pos }


let set_pos pos = function
  | TypedDecl (trs, sclasses, ty, untyped, asm, init) ->
      TypedDecl ({ trs with pos = pos.pos }, sclasses, ty, untyped, asm, init)
  | node -> node


let pos_of_expr expr = (traits_of_expr expr).pos
let pos_of_stmt stmt = (traits_of_stmt stmt).pos
let pos_of_type ty = (traits_of_type ty).pos
let pos_of_decl decl = (traits_of_decl decl).pos


let rec add_attrs = function
  | [] -> fun decl -> decl
  | attrs ->
      function
      | Nothing ->
          IdentifierDeclarator ({ empty with attrs = List.flatten attrs }, "")
      | IdentifierDeclarator (trs, id) ->
          IdentifierDeclarator ({ trs with attrs = (List.flatten attrs) @ trs.attrs }, id)
      | StructDeclarator (trs, decl, bitfield) ->
          StructDeclarator (trs, add_attrs attrs decl, bitfield)
      | TypedDecl (trs, sc, ty, decl, asm, init) ->
          TypedDecl (trs, sc, ty, add_attrs attrs decl, asm, init)
      | DeclaringList (trs, decl :: tl) ->
          DeclaringList (trs, add_attrs attrs decl :: tl)
      | FunctionDefinition (trs, decl, body) ->
          FunctionDefinition (trs, add_attrs attrs decl, body)
      | decl -> die (Declaration_error ("invalid declaration", [decl]))
