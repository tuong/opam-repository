open Ast

let unary a =
  match a with
  | TypedExpression (ty, value, expr) ->
      let ty =
        match ty with
        (* Convert char and short to int, keeping their signedness. *)
        | BasicType (SChar | SShort) -> BasicType SInt
        | BasicType (UChar | UShort) -> BasicType UInt
        | BasicType Char ->
            if Platform.char_is_signed then
              BasicType SInt
            else
              BasicType UInt
        (* Convert arrays to pointers. *)
        | ArrayType (_, base) -> PointerType (base)
        (* Convert functions to pointers to functions. *)
        | FunctionType _ as ty -> PointerType (ty)
        | ty -> ty
      in

      TypedExpression (ty, value, expr)
  | expr -> die (Expression_error ("usual unary conversions", [expr]))


let binary a b =
  match a, b with
  | TypedExpression (lty, lvalue, lexpr), TypedExpression (rty, rvalue, rexpr) ->
      let rank bt =
        match bt with
        | SInt		-> 1
        | UInt		-> 2
        | SLong		-> 3
        | ULong		-> 4
        | SLongLong	-> 5
        | ULongLong	-> 6
        | Float		-> 7
        | Double	-> 8
        | LongDouble	-> 9
        | bt		-> die (Type_error ("invalid basic type", [BasicType bt]))
      in

      let convert to_ty = function
        | TypedExpression (from_ty, evalue, expr) ->
            (* Convert value to floating point, if the target type is a
             * floating point type. *)
            let value =
              if Type.is_floating to_ty && not (Type.is_floating from_ty) then
                let open Constant in
                match evalue with
                | IntValue i ->
                    FloatValue (Big_int.float_of_big_int i)
                | _ -> raise (Failure "conversion")
              else
                evalue
            in

            TypedExpression (to_ty, value, expr)
        | expr ->
            die (Expression_error ("untyped expression in implicit conversion", [expr]))
      in

      begin match lty, rty with
      (* If the types are already equal, no conversion is required. *)
      | lty, rty when lty = rty -> a, b

      (* For basic types, convert the smaller type to the bigger type. *)
      | BasicType lbt, BasicType rbt ->
          begin match rank lbt < rank rbt with
          | true  -> (* Convert left expression to right type. *)
              convert rty a, b
          | false -> (* Convert right expression to left type. *)
              a, convert lty b
          end

      (* Complex types undergo no conversions. *)
      | _ ->
          a, b
      end

  | a, b -> die (Expression_error ("usual binary conversions", [a]))


(**
 * [coerce] tests whether assigning rhs to an object of ltype
 * is valid.
 *
 * Pointer/pointer and int/pointer coercions (except for constant 0)
 * are disallowed unless the caller explicitly specifies that they are
 * allowable:
 *
 * [ptr2intp == true] implies that pointers can be coerced to integral types
 * and back.
 *
 * [ptr2ptrp == true]  implies that pointers can be coerced regardless of
 * their base type.
 *
 * [ltype] is restricted to types which make sense in a cast.  In particular,
 * [ltype] may not be an array or function type (though it may be a pointer
 * to an array or function).
 *)
let coerce ptr2intp ptr2ptrp rhs ltype =
  match Type.type_of rhs with
  | TypedefType _ as ty -> die (Type_error ("unhandled type in coerce", [ltype; ty]))
  | _ -> rhs


let assignment = coerce false false
