(************************************************
 * Run all passes on the translation unit's AST *
 ************************************************)

let run_passes tu =
  (* Verify parse *)
  assert (Verify_tree.verify tu);

  (* Prepare tree for subsequent passes *)
  let tu = Normalise.normalise_unit tu in
  let tu = Assign_names.assign_names tu in

  (* Semantic checks. *)
  let tu =
    try
      (* Fill symbol table *)
      let symtab = Symtab.create () in
      Collect_syms.collect symtab tu;
      (*Symtab.print symtab;*)

      (* Check variable binding. *)
      Check_binding.check_unit symtab tu;

      (* Full semantic check including types and constant values. *)
      let tu = Typecheck.tcheck_unit symtab tu in
      (*Symtab.print symtab;*)

      tu
    with e ->
      if not Settings.w then
        raise e
      else
        tu
  in

  (* Information passes *)
  assert (Verify_tree.verify tu);
  assert (Warn_globals.process tu);

  tu
