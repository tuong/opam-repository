open Ast


(* {{{ *)

let iter = List.iter

type iter_struct = {
  iter_type : Ast.ctype -> unit;
  iter_expr : Ast.expression -> unit;
  iter_stmt : Ast.statement -> unit;
  iter_decl : Ast.declaration -> unit;
}

let opt fn = function
  | None -> ()
  | Some node -> fn node


let iter_stmt { iter_type = tfn; iter_expr = efn; iter_stmt = sfn; iter_decl = dfn } node =
  match node with
  | Nop -> ()

  (* Statements *)
  | CompoundStatement (_, stmts) -> iter sfn stmts
  | ExpressionStatement (_, expr) -> opt efn expr
  | DeclarationStatement (decl) -> dfn decl

  (* Labelled statements *)
  | LabelledStatement (_, _, stmt) -> sfn stmt
  | LocalLabel _ -> ()
  | CaseStatement (_, expr) -> efn expr
  | DefaultStatement _ -> ()

  (* Selection statements *)
  | IfStatement (_, cond, then_stmt, else_stmt) -> efn cond; sfn then_stmt; sfn else_stmt
  | SwitchStatement (_, expr, cases) -> efn expr; sfn cases

  (* Iteration statements *)
  | WhileStatement (_, cond, body) -> efn cond; sfn body
  | DoWhileStatement (_, body, cond) -> sfn body; efn cond
  | ForStatement (_, init, cond, next, body) -> opt efn init; opt efn cond; opt efn next; sfn body

  (* Jump statements *)
  | GotoStatement _ -> ()
  | ContinueStatement _ -> ()
  | BreakStatement _ -> ()
  | ReturnStatement (_, expr) -> opt efn expr

  (* GCC asm statement *)
  | AsmStatement (_, volatile, code, in_args, out_args, clobber, labels) ->
      let iter_arg (_, constr, expr) = efn expr in
      iter iter_arg in_args;
      iter iter_arg out_args


let iter_expr { iter_type = tfn; iter_expr = efn; iter_stmt = sfn; iter_decl = dfn } node =
  match node with
  (* Wildcards *)
  | WildcardExpr _ -> ()

  (* Expression with type information *)
  | TypedExpression (ty, value, expr) -> tfn ty; efn expr

  (* Expression *)
  | TernaryExpression (_, op, cond, then_expr, else_expr) -> efn cond; opt efn then_expr; efn else_expr
  | BinaryExpression (_, op, lhs, rhs) -> efn lhs; efn rhs
  | UnaryExpression (_, op, expr) -> efn expr
  | ArrayAccess (_, expr, index) -> efn expr; efn index
  | MemberAccess (_, expr, member) -> efn expr
  | PointerAccess (_, expr, member) -> efn expr
  | SizeofExpr (_, expr) -> efn expr
  | SizeofType (_, ty) -> tfn ty
  | AlignofExpr (_, expr) -> efn expr
  | AlignofType (_, ty) -> tfn ty
  | Offsetof (_, ty, member) -> tfn ty; efn member
  | TypesCompatibleP (_, ty1, ty2) -> tfn ty1; tfn ty2
  | VaArg (_, ap, ty) -> efn ap; tfn ty
  | FunctionCall (_, callee, args) -> efn callee; iter efn args
  | CompoundLiteral (_, ty, init) -> tfn ty; efn init

  (* Primary expression *)
  | Identifier _ -> ()
  | NumberLiteral _ -> ()
  | CharLiteral _ -> ()
  | StringLiteral _ -> ()
  | BraceExpression (_, stmt) -> sfn stmt

  (* Cast expression *)
  | Cast (_, ty, expr) -> tfn ty; efn expr

  (* Initialisers *)
  | InitialiserList (_, inits) -> iter efn inits
  | MemberDesignator (_) -> ()
  | ArrayLabelledInitialiser (_, index, init) -> efn index; efn init
  | DesignatedInitialiser (_, designator, init) -> efn designator; efn init


let iter_type { iter_type = tfn; iter_expr = efn; iter_stmt = sfn; iter_decl = dfn } node =
  match node with
  | NoType -> ()

  (* Wildcards *)
  | WildcardType _ -> ()

  (* Types *)
  | PartialBasicType _ -> ()
  | BasicType _ -> ()
  | QualifiedType (tquals, unqual) -> tfn unqual
  | PointerType (base) -> tfn base
  | SUEType (_, kind, tag, members) -> iter dfn members
  | TypedefType _ -> ()
  | ArrayType (arity, base) -> opt efn arity; tfn base
  | FunctionType (rettype, params) -> tfn rettype; iter dfn params
  | TypeofExpr (expr) -> efn expr
  | TypeofType (ty) -> tfn ty


let iter_decl { iter_type = tfn; iter_expr = efn; iter_stmt = sfn; iter_decl = dfn } node =
  match node with
  | Nothing -> ()
  | TranslationUnit (decls) -> iter dfn decls

  (* Wildcards *)
  | WildcardDecl _ -> ()

  (* #include etc. *)
  | PreprocessorDirective _ -> ()

  (* Syntax errors *)
  | SyntaxError (_, msg, node) -> dfn node

  (* Toplevel __asm__ *)
  | ToplevelAsm _ -> ()

  (* Generic nodes *)
  | AsmSpecifier _ -> ()
  | FunctionDefinition (_, decl, body) -> dfn decl; sfn body
  | IdentifierDeclarator _ -> ()
  | StructDeclarator (_, decl, bitfield) -> dfn decl; opt efn bitfield
  | TypedDecl (_, sclasses, ty, untyped, asm, init) -> tfn ty; dfn untyped; dfn asm; opt efn init
  | DeclaringList (_, decls) -> iter dfn decls

  (* Struct/union/enum types *)
  | Enumerator (_, id, value) -> opt efn value


let rec iter_struct = {
  iter_type = continue_type;
  iter_expr = continue_expr;
  iter_stmt = continue_stmt;
  iter_decl = continue_decl;
}

and continue_type n = iter_type iter_struct n
and continue_expr n = iter_expr iter_struct n
and continue_stmt n = iter_stmt iter_struct n
and continue_decl n = iter_decl iter_struct n


(* }}} *)
(* {{{ *)

let map = List.map

type map_struct = {
  map_type : Ast.ctype -> Ast.ctype;
  map_expr : Ast.expression -> Ast.expression;
  map_stmt : Ast.statement -> Ast.statement;
  map_decl : Ast.declaration -> Ast.declaration;
}

let opt fn = function
  | None -> None
  | Some node -> Some (fn node)


let map_stmt { map_type = tfn; map_expr = efn; map_stmt = sfn; map_decl = dfn } node =
  match node with
  | Nop -> node

  (* Statements *)
  | CompoundStatement (trs, stmts) -> CompoundStatement (trs, map sfn stmts)
  | ExpressionStatement (trs, expr) -> ExpressionStatement (trs, opt efn expr)
  | DeclarationStatement (decl) -> DeclarationStatement (dfn decl)

  (* Labelled statements *)
  | LabelledStatement (trs, label, stmt) -> LabelledStatement (trs, label, sfn stmt)
  | LocalLabel _ -> node
  | CaseStatement (trs, expr) -> CaseStatement (trs, efn expr)
  | DefaultStatement _ -> node

  (* Selection statements *)
  | IfStatement (trs, cond, then_stmt, else_stmt) -> IfStatement (trs, efn cond, sfn then_stmt, sfn else_stmt)
  | SwitchStatement (trs, expr, cases) -> SwitchStatement (trs, efn expr, sfn cases)

  (* Iteration statements *)
  | WhileStatement (trs, cond, body) -> WhileStatement (trs, efn cond, sfn body)
  | DoWhileStatement (trs, body, cond) -> DoWhileStatement (trs, sfn body, efn cond)
  | ForStatement (trs, init, cond, next, body) -> ForStatement (trs, opt efn init, opt efn cond, opt efn next, sfn body)

  (* Jump statements *)
  | GotoStatement _ -> node
  | ContinueStatement _ -> node
  | BreakStatement _ -> node
  | ReturnStatement (trs, expr) -> ReturnStatement (trs, opt efn expr)

  (* GCC asm statement *)
  | AsmStatement (trs, volatile, code, in_args, out_args, clobber, labels) ->
      let map_arg (trs, constr, expr) = (trs, constr, efn expr) in
      AsmStatement (trs, volatile, code, map map_arg in_args, map map_arg out_args, clobber, labels)


let map_expr { map_type = tfn; map_expr = efn; map_stmt = sfn; map_decl = dfn } = function
  (* Wildcards *)
  | WildcardExpr _ as node -> node

  (* Expression with type information *)
  | TypedExpression (ty, value, expr) -> TypedExpression (tfn ty, value, efn expr)

  (* Expression *)
  | TernaryExpression (trs, op, cond, then_expr, else_expr) -> TernaryExpression (trs, op, efn cond, opt efn then_expr, efn else_expr)
  | BinaryExpression (trs, op, lhs, rhs) -> BinaryExpression (trs, op, efn lhs, efn rhs)
  | UnaryExpression (trs, op, expr) -> UnaryExpression (trs, op, efn expr)
  | ArrayAccess (trs, expr, index) -> ArrayAccess (trs, efn expr, efn index)
  | MemberAccess (trs, expr, member) -> MemberAccess (trs, efn expr, member)
  | PointerAccess (trs, expr, member) -> PointerAccess (trs, efn expr, member)
  | SizeofExpr (trs, expr) -> SizeofExpr (trs, efn expr)
  | SizeofType (trs, ty) -> SizeofType (trs, tfn ty)
  | AlignofExpr (trs, expr) -> AlignofExpr (trs, efn expr)
  | AlignofType (trs, ty) -> AlignofType (trs, tfn ty)
  | Offsetof (trs, ty, member) -> Offsetof (trs, tfn ty, efn member)
  | TypesCompatibleP (trs, ty1, ty2) -> TypesCompatibleP (trs, tfn ty1, tfn ty2)
  | VaArg (trs, ap, ty) -> VaArg (trs, efn ap, tfn ty)
  | FunctionCall (trs, callee, args) -> FunctionCall (trs, efn callee, map efn args)
  | CompoundLiteral (trs, ty, init) -> CompoundLiteral (trs, tfn ty, efn init)

  (* Primary expression *)
  | Identifier _
  | NumberLiteral _
  | CharLiteral _
  | StringLiteral _ as node -> node
  | BraceExpression (trs, stmt) -> BraceExpression (trs, sfn stmt)

  (* Cast expression *)
  | Cast (trs, ty, expr) -> Cast (trs, tfn ty, efn expr)

  (* Initialisers *)
  | InitialiserList (trs, inits) -> InitialiserList (trs, map efn inits)
  | MemberDesignator (members) as node -> node
  | ArrayLabelledInitialiser (trs, index, init) -> ArrayLabelledInitialiser (trs, efn index, efn init)
  | DesignatedInitialiser (trs, designator, init) -> DesignatedInitialiser (trs, efn designator, efn init)


let map_type { map_type = tfn; map_expr = efn; map_stmt = sfn; map_decl = dfn } = function
  | NoType -> NoType

  (* Wildcards *)
  | WildcardType _ as node -> node

  (* Types *)
  | PartialBasicType _ as node -> node
  | BasicType _ as node -> node
  | QualifiedType (tquals, unqual) -> QualifiedType (tquals, tfn unqual)
  | PointerType (base) -> PointerType (tfn base)
  | SUEType (attr, kind, tag, members) -> SUEType (attr, kind, tag, map dfn members)
  | TypedefType _ as node -> node
  | ArrayType (arity, base) -> ArrayType (opt efn arity, tfn base)
  | FunctionType (rettype, params) -> FunctionType (tfn rettype, map dfn params)
  | TypeofExpr (expr) -> TypeofExpr (efn expr)
  | TypeofType (ty) -> TypeofType (tfn ty)


let map_decl { map_type = tfn; map_expr = efn; map_stmt = sfn; map_decl = dfn } node =
  match node with
  | Nothing -> node
  | TranslationUnit (decls) -> TranslationUnit (map dfn decls)

  (* Wildcards *)
  | WildcardDecl _ -> node

  (* #include etc. *)
  | PreprocessorDirective _ -> node

  (* Syntax errors *)
  | SyntaxError (trs, msg, node) -> SyntaxError (trs, msg, dfn node)

  (* Statements *)
  | ToplevelAsm _ -> node

  (* Generic nodes *)
  | AsmSpecifier _ -> node
  | FunctionDefinition (trs, decl, body) -> FunctionDefinition (trs, dfn decl, sfn body)
  | IdentifierDeclarator _ -> node
  | StructDeclarator (trs, decl, bitfield) -> StructDeclarator (trs, dfn decl, opt efn bitfield)
  | TypedDecl (trs, sclasses, ty, untyped, asm, init) -> TypedDecl (trs, sclasses, tfn ty, dfn untyped, dfn asm, opt efn init)
  | DeclaringList (trs, decls) -> DeclaringList (trs, map dfn decls)

  (* Struct/union/enum types *)
  | Enumerator (trs, id, value) -> Enumerator (trs, id, opt efn value)


let rec map_struct = {
  map_type = continue_type;
  map_expr = continue_expr;
  map_stmt = continue_stmt;
  map_decl = continue_decl;
}

and continue_type n = map_type map_struct n
and continue_expr n = map_expr map_struct n
and continue_stmt n = map_stmt map_struct n
and continue_decl n = map_decl map_struct n


(* }}} *)
(* {{{ *)

let fold_left = List.fold_left

type 'a fold_struct = {
  fold_type : 'a -> Ast.ctype -> 'a;
  fold_expr : 'a -> Ast.expression -> 'a;
  fold_stmt : 'a -> Ast.statement -> 'a;
  fold_decl : 'a -> Ast.declaration -> 'a;
}

let opt fn data = function
  | None -> data
  | Some node -> fn data node


let fold_stmt { fold_type = tfn; fold_expr = efn; fold_stmt = sfn; fold_decl = dfn } data node =
  match node with
  | Nop -> data

  (* Statements *)
  | CompoundStatement (_, stmts) -> fold_left sfn data stmts
  | ExpressionStatement (_, expr) -> opt efn data expr
  | DeclarationStatement (decl) -> dfn data decl

  (* Labelled statements *)
  | LabelledStatement (_, label, stmt) -> sfn data stmt
  | LocalLabel _ -> data
  | CaseStatement (_, expr) -> efn data expr
  | DefaultStatement _ -> data

  (* Selection statements *)
  | IfStatement (_, cond, then_stmt, else_stmt) -> sfn (sfn (efn data cond) then_stmt) else_stmt
  | SwitchStatement (_, expr, cases) -> sfn (efn data expr) cases

  (* Iteration statements *)
  | WhileStatement (_, cond, body) -> sfn (efn data cond) body
  | DoWhileStatement (_, body, cond) -> efn (sfn data body) cond
  | ForStatement (_, init, cond, next, body) -> sfn (opt efn (opt efn (opt efn data init) cond) next) body

  (* Jump statements *)
  | GotoStatement _ -> data
  | ContinueStatement _ -> data
  | BreakStatement _ -> data
  | ReturnStatement (_, expr) -> opt efn data expr

  (* GCC asm statement *)
  | AsmStatement (_, volatile, code, in_args, out_args, clobber, labels) ->
      let fold_arg data (_, constr, expr) = efn data expr in
      fold_left fold_arg (fold_left fold_arg data in_args) out_args


let fold_expr { fold_type = tfn; fold_expr = efn; fold_stmt = sfn; fold_decl = dfn } data node =
  match node with
  (* Wildcards *)
  | WildcardExpr _ -> data

  (* Expression with type information *)
  | TypedExpression (ty, value, expr) -> efn (tfn data ty) expr

  (* Expression *)
  | TernaryExpression (_, op, cond, then_expr, else_expr) -> efn (opt efn (efn data cond) then_expr) else_expr
  | BinaryExpression (_, op, lhs, rhs) -> efn (efn data lhs) rhs
  | UnaryExpression (_, op, expr) -> efn data expr
  | ArrayAccess (_, expr, index) -> efn (efn data expr) index
  | MemberAccess (_, expr, member) -> efn data expr
  | PointerAccess (_, expr, member) -> efn data expr
  | SizeofExpr (_, expr) -> efn data expr
  | SizeofType (_, ty) -> tfn data ty
  | AlignofExpr (_, expr) -> efn data expr
  | AlignofType (_, ty) -> tfn data ty
  | Offsetof (_, ty, member) -> efn (tfn data ty) member
  | TypesCompatibleP (_, ty1, ty2) -> tfn (tfn data ty1) ty2
  | VaArg (_, ap, ty) -> tfn (efn data ap) ty
  | FunctionCall (_, callee, args) -> fold_left efn (efn data callee) args
  | CompoundLiteral (_, ty, init) -> efn (tfn data ty) init

  (* Primary expression *)
  | Identifier _
  | NumberLiteral _
  | CharLiteral _
  | StringLiteral _ -> data
  | BraceExpression (_, stmt) -> sfn data stmt

  (* Cast expression *)
  | Cast (_, ty, expr) -> efn (tfn data ty) expr

  (* Initialisers *)
  | InitialiserList (_, inits) -> fold_left efn data inits
  | MemberDesignator (_) -> data
  | ArrayLabelledInitialiser (_, index, init) -> efn (efn data index) init
  | DesignatedInitialiser (_, designator, init) -> efn (efn data designator) init


let fold_type { fold_type = tfn; fold_expr = efn; fold_stmt = sfn; fold_decl = dfn } data node =
  match node with
  | NoType -> data

  (* Wildcards *)
  | WildcardType _ -> data

  (* Types *)
  | PartialBasicType _ -> data
  | BasicType _ -> data
  | QualifiedType (tquals, unqual) -> tfn data unqual
  | PointerType (base) -> tfn data base
  | SUEType (_, kind, tag, members) -> fold_left dfn data members
  | TypedefType _ -> data
  | ArrayType (arity, base) -> tfn (opt efn data arity) base
  | FunctionType (rettype, params) -> fold_left dfn (tfn data rettype) params
  | TypeofExpr (expr) -> efn data expr
  | TypeofType (ty) -> tfn data ty


let fold_decl { fold_type = tfn; fold_expr = efn; fold_stmt = sfn; fold_decl = dfn } data node =
  match node with
  | Nothing -> data
  | TranslationUnit (decls) -> fold_left dfn data decls

  (* Wildcards *)
  | WildcardDecl _ -> data

  (* #include etc. *)
  | PreprocessorDirective _ -> data

  (* Syntax errors *)
  | SyntaxError (_, msg, node) -> dfn data node

  (* Toplevel __asm__ *)
  | ToplevelAsm _ -> data

  (* Generic nodes *)
  | AsmSpecifier _ -> data
  | FunctionDefinition (_, decl, body) -> sfn (dfn data decl) body
  | IdentifierDeclarator _ -> data
  | StructDeclarator (_, decl, bitfield) -> opt efn (dfn data decl) bitfield
  | TypedDecl (_, sclasses, ty, untyped, asm, init) -> opt efn (dfn (dfn (tfn data ty) untyped) asm) init
  | DeclaringList (_, decls) -> fold_left dfn data decls

  (* Struct/union/enum types *)
  | Enumerator (_, id, value) -> opt efn data value


let rec fold_struct = {
  fold_type = continue_type;
  fold_expr = continue_expr;
  fold_stmt = continue_stmt;
  fold_decl = continue_decl;
}

and continue_type a n = fold_type fold_struct a n
and continue_expr a n = fold_expr fold_struct a n
and continue_stmt a n = fold_stmt fold_struct a n
and continue_decl a n = fold_decl fold_struct a n


(* }}} *)
