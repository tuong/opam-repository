(******************************************************************************)
(*  ocsigen-bundler: create self-contained Ocsigen application package        *)
(*                                                                            *)
(*  Copyright (C) 2011, OCamlCore SARL                                        *)
(*                                                                            *)
(*  This library/application is free software; you can redistribute it        *)
(*  and/or modify it under the terms of the GNU Lesser General Public         *)
(*  License as published by the Free Software Foundation; either version 2.1  *)
(*  of the License, or (at your option) any later version, with the OCaml     *)
(*  static compilation exception.                                             *)
(*                                                                            *)
(*  This library/application is distributed in the hope that it will be       *)
(*  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of    *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the file         *)
(*  COPYING for more details.                                                 *)
(*                                                                            *)
(*  You should have received a copy of the GNU Lesser General Public License  *)
(*  along with this library; if not, write to the Free Software Foundation,   *)
(*  Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA             *)
(******************************************************************************)

open OUnit

let bracket_tmpdir f = 
  bracket
    (fun () ->
       let dn =
         Filename.temp_file "ocsigen-bundler-" ".dir"
       in
         FileUtil.rm [dn];
         FileUtil.mkdir dn;
         dn)
    f
    (fun dn ->
       FileUtil.rm ~recurse:true [dn])


let in_data_dir fn =
  FilePath.make_filename ["test"; "data"; fn]
