(* OASIS_START *)
(* DO NOT EDIT (digest: e1ad120aaf48abe23a1aea91549cfd3d) *)
This is the README file for the ocsigen-bundler distribution.

(C) 2011 OCamlCore SARL

Create self-contained Ocsigen server

This project helps to create self contained Ocsigen web server with its Eliom
modules. It is a mean to easily deploy an Ocsigen server on a server without
OCaml or Ocsigen installed.

One of its main use is to deploy Ocsigen application on ocamlcore.org. Here
is a list of some of them:

- [OASIS](http://oasis.ocamlcore.org) - [OCaml
Meeting](http://ocaml-meeting.forge.ocamlcore.org/2011-paris/reg_view) -
[OCamlCore API test](http://ocamlcore-api.forge.ocamlcore.org)

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 

Home page: http://ocsigen-bundler.forge.ocamlcore.org/


(* OASIS_STOP *)
