(******************************************************************************)
(*  ocsigen-bundler: create self-contained Ocsigen application package        *)
(*                                                                            *)
(*  Copyright (C) 2011, OCamlCore SARL                                        *)
(*                                                                            *)
(*  This library/application is free software; you can redistribute it        *)
(*  and/or modify it under the terms of the GNU Lesser General Public         *)
(*  License as published by the Free Software Foundation; either version 2.1  *)
(*  of the License, or (at your option) any later version, with the OCaml     *)
(*  static compilation exception.                                             *)
(*                                                                            *)
(*  This library/application is distributed in the hope that it will be       *)
(*  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of    *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the file         *)
(*  COPYING for more details.                                                 *)
(*                                                                            *)
(*  You should have received a copy of the GNU Lesser General Public License  *)
(*  along with this library; if not, write to the Free Software Foundation,   *)
(*  Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA             *)
(******************************************************************************)

open Xml
open ExtLib

type t = 
    {
      modules          : string list;
      findlib_packages : string list;
      copies           : (string * string) list;
      logdir_set       : bool;
      commandpipe_set  : bool;
      port_set         : bool;
    }

let () =
  Findlib.init ()

exception Warning of string 

module SetRootPkg = Set.Make(String)
module SetString = Set.Make(String)

let make ?(verbose=false) ?(dry_run=false) ?port ?logdir fn tgt = 

  let stublib_dir = 
    "/usr/lib/ocaml/stublibs"
  in

  let info fmt = 
    if verbose then
      begin
        Printf.printf "I: ";
        Printf.kfprintf
          (fun chn -> Printf.fprintf chn "\n%!")
          stdout
          fmt
      end
    else
      begin
        Printf.ifprintf stdout fmt
      end
  in

  let warning fmt = 
    Printf.eprintf "W: ";
    Printf.kfprintf 
      (fun chn -> Printf.fprintf chn "\n%!")
      stderr
      fmt
  in

  let bindir = 
    "bin"
  in

  let logdir, mkdir_logdir = 
    match logdir with 
      | Some s ->
          s, false
      | None ->
          "log", true
  in

  let etcdir = 
    "etc"
  in

  let moddir = 
    "mod"
  in

  let rundir = 
    "run"
  in

  let libdir = 
    "lib"
  in
  
  let ocamldir =
    FilePath.concat libdir "ocaml"
  in
    
  let _metasdir =
    FilePath.concat ocamldir "METAS"
  in

  let stubdir =
    FilePath.concat ocamldir "stublibs"
  in

  let commandpipe =
    FilePath.concat rundir "ocsigen_command"
  in

  let rec partition_one nm lst =
    match lst with 
      | (nm', res) :: tl when nm' = nm ->
          res, tl

      | e :: tl ->
          let res , tl =
            partition_one nm tl
          in
            res, e :: tl

      | [] ->
          raise Not_found
  in

  let rec parse t =
    function
      | Element ("extension", attrs, children) as xml ->
          begin
            try
              let fnd_pkg = 
                List.assoc "findlib-package" attrs
              in
                xml,
                {t with 
                  findlib_packages = fnd_pkg :: t.findlib_packages}

            with Not_found ->
              failwith "Unhandle extension element"
          end

      | Element ("eliom", attrs, children) ->
          begin
            try 
              let modl, attrs = 
                partition_one "module" attrs
              in
              let new_modl = 
                FilePath.make_filename 
                  [moddir; FilePath.basename modl]
              in
                Element ("eliom",
                         (("module", new_modl) :: attrs),
                         children),
                {t with 
                  modules = modl :: t.modules;
                  copies  = (modl, new_modl) :: t.copies }

            with Not_found ->
              failwith "Unhandle eliom element"
          end

      | Element ("logdir", attrs, children) ->
          Element ("logdir", attrs, [PCData logdir]),
          {t with logdir_set = true}

      | Element ("commandpipe", attrs, children) ->
          Element ("commandpipe", attrs, [PCData commandpipe]),
          {t with commandpipe_set = true}

      | Element ("port", attrs, children) as e ->
          begin
            match port with 
              | Some n ->
                  Element("port", attrs, [PCData (string_of_int n)]),
                  {t with port_set = true}
              | None ->
                  e, t
          end

      | Element (nm, attrs, children) as xml ->
          let children, t = 
            fold 
              (fun (acc, t) xml ->
                 let e, t = 
                   parse t xml
                 in
                   e :: acc, t)
              ([], t) 
              xml
          in
          let children =  
            List.rev children
          in
          let children = 
            if nm = "server" then
              begin
                let children = 
                  List.fold_left
                    (fun acc (tst, nm, vl) ->
                       if tst then
                         Element (nm, [], [PCData vl]) :: acc
                       else
                         acc)
                    children
                    [
                      t.logdir_set, "logdir", logdir;
                      t.commandpipe_set, "commandpipe", commandpipe;
                    ]
                in
                let children =
                  match t.port_set, port with
                    | false, Some n ->
                        (Element ("port", [], [PCData (string_of_int n)])) 
                        :: 
                        children
                    | _, _ ->
                        children
                in
                  children
              end
            else
              children
          in
            Element (nm, attrs, children),
            t

      | PCData str as pcdata ->
          pcdata, t
  in

  let xml, t = 
    parse 
      {
        modules          = [];
        findlib_packages = [];
        copies           = [];
        port_set         = false;
        commandpipe_set  = false;
        logdir_set       = false;
      } 
      (Xml.parse_file fn)
  in

  let findlib_copies = 
    let predicates = 
      ["byte"; "mt"]
    in
    let pkg_prop pkg prop = 
      try 
        Findlib.package_property 
          predicates 
          pkg 
          prop
      with Not_found ->
        raise 
          (Warning
             (Printf.sprintf 
                "Findlib property '%s' not found for package '%s'" 
                prop pkg))
    in

    let to_root_pkg pkg = 
      try 
        fst (String.split pkg ".")
      with Invalid_string ->
        pkg
    in

    let to_meta root_pkg = 
      try 
        let lst = 
          List.fold_left 
            (fun acc dn ->
               (true, FilePath.concat dn ("META."^root_pkg))
               ::
               (false, FilePath.make_filename [dn; root_pkg; "META"])
               ::
               acc)
            []
            (Findlib.search_path ())
        in
          List.find 
            (fun (_, fn) -> Sys.file_exists fn) 
            (List.rev lst)
      with Not_found -> 
        failwith 
          (Printf.sprintf 
             "META file not found for package '%s'"
             root_pkg)
    in

    let to_archive pkg = 
      let archives = 
        String.nsplit 
          (pkg_prop pkg "archive")
          " "
      in
      let archives = 
        List.filter (( <> ) "") archives
      in
        archives
    in

    let lst = 
      Findlib.package_deep_ancestors 
        predicates 
        t.findlib_packages
    in

    let copies = 
      []
    in

    let copies, _ = 
      (* Copy META files *)
      List.fold_left
        (fun (lst, st) pkg ->
           let root_pkg = 
             to_root_pkg pkg
           in
             if not (SetRootPkg.mem root_pkg st) then
               begin
                 let is_outdir, meta = 
                   to_meta root_pkg
                 in
                 let bn = 
                   FilePath.basename meta
                 in
                 let tgt = 
                   if is_outdir then
                     FilePath.concat "METAS" bn 
                   else
                     FilePath.concat root_pkg bn
                 in
                   (meta, tgt) :: lst,
                   SetRootPkg.add root_pkg st
               end
             else
               lst, st)
        (copies, SetRootPkg.empty)
        lst
    in

    let copies = 
      (* Copy archive files *)
      List.fold_left
        (fun acc pkg ->
           try 
             let archives = 
               to_archive pkg
             in
               
             let location =
               Findlib.package_directory pkg
             in

             let to_tgt =
               if location = Findlib.ocaml_stdlib () then
                 (* This is a standard library *)
                 fun s -> s
               else
                 FilePath.concat (to_root_pkg pkg)
             in
               List.fold_left
                 (fun acc fn ->
                    (FilePath.concat location fn, to_tgt fn)
                    ::
                    acc)
                 acc
                 archives
        
           with Warning msg ->
             warning "%s" msg;
             acc)
        copies
        lst
    in

    let copies = 
      (FilePath.make_filename [Findlib.ocaml_stdlib (); "threads"; "threads.cma"],
       FilePath.concat "threads" "threads.cma")
      ::
      (FilePath.make_filename [Findlib.ocaml_stdlib (); "vmthreads"; "threads.cma"],
       FilePath.concat "vmthreads" "threads.cma")
      :: copies
    in

      copies
  in

  let install ?tgt_rel (src, tgt_tl) = 
    let tgt_fn = 
      match tgt_rel with 
        | Some tgt_rel ->
            FilePath.make_filename [tgt; tgt_rel; tgt_tl]
        | None ->
            FilePath.concat tgt tgt_tl
    in
      info "install '%s' -> '%s'" src tgt_fn;
      if not dry_run then
        begin
          FileUtil.mkdir ~parent:true (FilePath.dirname tgt_fn);
          FileUtil.cp [src] tgt_fn
        end
  in

  let info_mkdir dn = 
    let dn =
      FilePath.concat tgt dn
    in
      info "mkdir '%s'" dn;
      if not dry_run then
        FileUtil.mkdir ~parent:true dn
  in

  let install_native cmd = 
    install ~tgt_rel:bindir (FileUtil.which cmd, cmd);
    if not dry_run then 
      Unix.chmod (FilePath.make_filename [tgt; bindir; cmd]) 0o755
  in

  let stub_copies = 
    let to_dll acc cma =
      let cmd_line = 
        Printf.sprintf "ocamlobjinfo '%s'" cma
      in
      let chn =
        Unix.open_process_in cmd_line
      in
      let racc =
        ref acc
      in
      let () = 
        try 
          while true do 
            let line = 
              input_line chn
            in
              try 
                ignore "(*";
                match Pcre.extract
                        ~pat:" *Extra C object files: *(.*)"
                        line with 
                  | [| _; str |] ->
                      begin
                        let arr = 
                          Pcre.extract_all ~pat:"-l([^ ]+)" str
                        in
                          Array.iter
                            (function 
                               | [| _; hd |] ->
                                   racc := SetString.add hd !racc
                               | _ ->
                                   ())
                            arr
                      end

                  | _ ->
                      ()
              with Not_found ->
                ()
          done
        with End_of_file ->
          ()
      in
      let () = 
        match Unix.close_process_in chn with 
          | Unix.WEXITED 0 -> 
              ()
          | _ -> 
              failwith 
                (Printf.sprintf 
                   "Command '%s' exited with non zero status code." 
                   cmd_line)
      in
        !racc
    in

    let find_dll nm = 
      let dll =
        FilePath.concat
          stublib_dir
          (Printf.sprintf "dll%s.so" nm)
      in
        if Sys.file_exists dll then
          dll
        else
          raise Not_found
    in

    let cma = 
      List.filter 
        (fun fn -> 
           FilePath.check_extension fn "cma"
           ||
           FilePath.check_extension fn "cmo")
        (List.map fst (List.rev_append t.copies findlib_copies))
    in

    let dll = 
      List.fold_left to_dll SetString.empty cma
    in

    let dll_fn = 
      SetString.fold 
        (fun nm acc ->
           try 
             find_dll nm :: acc
           with Not_found ->
             acc)
        (SetString.add "threads" dll)
        []
    in
      List.map (fun fn -> fn, FilePath.basename fn) dll_fn
  in

    if mkdir_logdir then 
      info_mkdir logdir;

    info_mkdir rundir;
    info_mkdir etcdir;

    List.iter install t.copies;
    install_native "ocsigen";
    install_native "ocamlrun";
    List.iter (install ~tgt_rel:ocamldir) findlib_copies;
    List.iter (install ~tgt_rel:stubdir) stub_copies;

    begin
      let fn = 
        FilePath.make_filename [tgt; etcdir; "ocsigen.conf"]
      in
      let ctnt = 
        Xml.to_string_fmt xml
      in
        info "Creating file '%s'" fn;
        List.iter 
          (fun s -> info "%s" s)
          (String.nsplit ctnt "\n");
        if not dry_run then
          let chn = 
            open_out fn
          in
            output_string chn ctnt;
            close_out chn
    end;

    begin
      let fn =
        FilePath.concat tgt "daemon.sh"
      in
        info "Creating file '%s'" fn;
        if not dry_run then
          let chn =
            open_out fn
          in
            output_string 
              chn
              Ocsigen_bundler_data.daemon_sh;
            close_out chn;
            Unix.chmod fn 0o755
    end;



