#! /bin/sh

# Daemon script inspired by the one written by Samuel Mimram for Debian 

CURDIR="$(dirname $(readlink -m $0))"
OCAMLLIB="$CURDIR/lib/ocaml"
LD_LIBRARY_PATH="$CURDIR/lib/ocaml/stublibs"
OCAMLPATH="$OCAMLLIB:$CURDIR/lib/ocaml/METAS"
PATH="$CURDIR/bin:$PATH"

export OCAMLLIB
export LD_LIBRARY_PATH
export OCAMLPATH
export PATH

DAEMON="$CURDIR/bin/ocsigen"
NAME=ocsigen
DESC=ocsigen
PIDFILE="$CURDIR/run/ocsigen.pid"
DEFAULTFILE="$CURDIR/etc/default.sh"
CONFFILE="$CURDIR/etc/ocsigen.conf"

test -x $DAEMON || exit 0

# Include ocsigen defaults if available
if [ -f $DEFAULTFILE ] ; then
  . $DEFAULTFILE
fi

set -e

case "$1" in
  start)
    if [ -r "$PIDFILE" ] && read pid < "$PIDFILE" && ps -p "$pid" > /dev/null 2>&1; then
      echo "$NAME is already running!"
      exit 0
    fi
    echo -n "Starting $DESC: "
    "$CURDIR/bin/ocamlrun" $DAEMON --daemon --pidfile $PIDFILE -c $CONFFILE $DAEMON_OPTS
    echo "$NAME."
    ;;
  stop)
    echo -n "Stopping $DESC: "
    for pid in `cat $PIDFILE`; do kill $pid || true; done
    rm -f $PIDFILE
    echo "$NAME."
    ;;
  reload)
    echo -n "Reloading $DESC: "
    echo reload > "$CURDIR/run/ocsigen_command"
    echo "$NAME."
    ;;
  restart|force-reload)
    $0 stop
    $0 start
    ;;
  status)
    echo -n "Status of $DESC: "
    if [ ! -r "$PIDFILE" ]; then
      echo "$NAME is not running."
      exit 3
    fi
    if read pid < "$PIDFILE" && ps -p "$pid" > /dev/null 2>&1; then
      echo "$NAME is running."
      exit 0
    else
      echo "$NAME is not running but $PIDFILE exists."
      exit 1
    fi
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|reload|force-reload|status}" >&2
    exit 1
    ;;
esac

exit 0
