(* OASIS_START *)
(* DO NOT EDIT (digest: c544e8815ae450c0a775d2d940e6dc39) *)
This is the README file for the lwt-zmq distribution.

Lwt-friendly interface to ZeroMQ

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
