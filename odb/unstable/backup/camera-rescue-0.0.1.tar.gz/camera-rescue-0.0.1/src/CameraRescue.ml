(*****************************************************************************)
(*  camera-rescue: Recover JPEG files from MMC/SD/CF camera memory card      *)
(*                                                                           *)
(*  Copyright (C) 2010, OCamlCore SARL                                       *)
(*                                                                           *)
(*  This program is free software; you can redistribute it and/or modify     *)
(*  it under the terms of the GNU General Public License as published by     *)
(*  the Free Software Foundation; either version 2 of the License.           *)
(*                                                                           *)
(*  This program is distributed in the hope that it will be useful,          *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of           *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *)
(*  GNU General Public License for more details.                             *)
(*                                                                           *)
(*  You should have received a copy of the GNU General Public License along  *)
(*  with this program; if not, write to the Free Software Foundation, Inc.,  *)
(*  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *)
(*****************************************************************************)

open LargeFile 

type t =
  | JPEGError 
  | JPEGReadSize
  | JPEGNoSize
  | JPEGEntropyCoded
  | JPEGEnd

let () = 
  let fn = 
    if Array.length Sys.argv > 1 then
      Sys.argv.(1)
    else
      failwith "You must provide an input filename"
  in
  let chn = 
    open_in_bin fn
  in


  (*
   *
   * Binary search in the raw file 
   *
   *)

  let buff = 
    String.make (8 * 1024) '\000'
  in

  let update_progress () = 
    Printf.eprintf "Scan progress: %03.2f%%\r%!" 
      ((Int64.to_float (pos_in chn)) *. 100. /. 
       (Int64.to_float (in_channel_length chn)))
  in

  let rec find_start c = 
    let len = 
      input chn buff 0 (String.length buff)
    in
    let found =
      update_progress ();
      if len = 0 then
        raise End_of_file;
      try 
        let pos = 
          String.index buff c
        in
          if pos < len then 
            begin
              (* We found something move the file cursor here *)
              seek_in chn 
                (Int64.sub 
                   (pos_in chn) 
                   (Int64.of_int (len - pos)));
              true
            end
          else
            begin
              false
            end

      with Not_found ->
        false

    in
      if not found then
        find_start c
  in

  let rec find_binary exp_str = 
    let exp_len = 
      String.length exp_str
    in
    let read_str = 
      String.make exp_len 'x'
    in
    let start_pos = 
      assert(exp_len > 0);
      (* Find the first char *)
      find_start exp_str.[0];
      pos_in chn
    in
      really_input chn read_str 0 exp_len;
      if read_str = exp_str then
        seek_in chn start_pos
      else
        find_binary exp_str
  in


  (*
   *
   * Find a JPEG by analyzing the content of RAW
   *
   *)

  let jpeg_begin =
    "\xff\xd8"
  in

  let jpeg_markers = 
    let a = 
      Array.make 256 ("Unknown", JPEGError)
    in
      for i = 0xC0 to 0xCF do 
        a.(i) <- (Printf.sprintf "SOF%02d" (i - 0XC0), JPEGReadSize)
      done;

      for i = 0xD0 to 0xDF do 
        a.(i) <- Printf.sprintf "RST%d" (i - 0xD0), JPEGError
      done;

      for i = 0xE0 to 0xEF do
        a.(i) <- Printf.sprintf "APP%d" (i - 0xE0), JPEGReadSize
      done;

      for i = 0xF0 to 0xFD do 
        a.(i) <- Printf.sprintf "JPG%d" (i - 0xF0), JPEGReadSize
      done;

      for i = 0x02 to 0xBF do 
        a.(i) <- "RES", JPEGReadSize
      done;

      List.iter
        (fun (i, nm, process) ->
           a.(i) <- nm, process)
        [
          0xC4, "DHT", JPEGReadSize;
          0xCC, "DAC", JPEGReadSize;
          0xD8, "SOI", JPEGNoSize;
          0xD9, "EOI", JPEGEnd;
          0xDA, "SOS", JPEGEntropyCoded;
          0xDB, "DQT", JPEGReadSize;
          0xDC, "DNL", JPEGReadSize;
          0xDD, "DRI", JPEGError;
          0xDE, "DHP", JPEGReadSize;
          0xDF, "EXP", JPEGReadSize;
          0xFE, "COM", JPEGReadSize;
          0x01, "TEM", JPEGNoSize;
        ];
      a
  in

  let scan_jpeg () = 
    let start_pos = pos_in chn in

    let input_charcode chn = 
      Char.code (input_char chn)
    in

    let assert_input_charcode x = 
      let c = input_charcode chn in
        if c <> x then
          failwith 
            (Printf.sprintf "Unexpected char %02x at position %08Lx"
               c (pos_in chn))
    in

    let skip_length len =
      seek_in chn (Int64.add (pos_in chn) (Int64.of_int len))
    in

    let rec scan_jpeg' () = 
      let () = 
        assert_input_charcode 0xff
      in
      let code =
        input_charcode chn
      in
      let mark nm msg = 
        Printf.eprintf "%08Lx: %s %s\n%!" (pos_in chn) nm msg
      in
        match jpeg_markers.(code) with
          | nm, JPEGReadSize ->
              let h = input_charcode chn in
              let l = input_charcode chn in
              let sz = (h * 256 + l) - 2 in
                mark nm (Printf.sprintf "skip %d bytes" sz);
                skip_length sz;
                scan_jpeg' ()
              
          | nm, JPEGNoSize ->
              mark nm "cont next byte";
              scan_jpeg' ()

          | nm, JPEGEntropyCoded ->
              let check_stuffed () = 
                assert_input_charcode 0XFF;
                input_charcode chn = 0
              in
                mark nm "entropy skip";
                find_start '\xff';
                while check_stuffed () do 
                  find_start '\xff'
                done;
                (* Go back to the start of the marker *)
                seek_in chn (Int64.sub (pos_in chn) 2L);
                scan_jpeg' ()

          | nm, JPEGEnd ->
              mark nm "end";
              pos_in chn

          | nm, JPEGError ->
              mark nm "error";
              failwith "JPEG Error"
    in

    let res = 
      try 
        begin
          assert_input_charcode 0xff;
          assert_input_charcode 0xd8;
          seek_in chn start_pos;
          Some (start_pos, scan_jpeg' ())
        end
      with Failure msg ->
        begin
          prerr_endline msg;
          None
        end
    in
      seek_in chn start_pos;
      res
  in

  let rec find_jpeg () = 
    find_binary jpeg_begin;
    match scan_jpeg () with
      | Some res -> 
          res
      | None -> 
          seek_in chn (Int64.succ (pos_in chn));
          find_jpeg ()
  in

  let copy_img fn start_pos end_pos = 
    let cur_pos = 
      pos_in chn
    in
    let buff = 
      String.make (Int64.to_int (Int64.sub end_pos start_pos)) 'x' 
    in
    let () =
      seek_in chn start_pos;
      really_input chn buff 0 (String.length buff);
      seek_in chn cur_pos
    in
    let chn_out = 
      open_out_bin fn
    in
      output_string chn_out buff;
      close_out chn_out;
      Printf.eprintf 
        "Extracted image to %s (%d KB)\n%!" 
        fn 
        ((String.length buff) / 1024)
  in

  let nimg = 
    ref 0
  in

  let rec scan_raw () = 
    let start_pos, end_pos = 
      find_jpeg ()
    in
    let fn =
      incr nimg;
      Printf.sprintf "IMG%04d.jpeg" !nimg
    in
      copy_img fn start_pos end_pos;
      seek_in chn end_pos;
      scan_raw ()
  in

    try 
      (* Go to the start of the first image *)
      scan_raw ()
    with 
      | Not_found 
      | End_of_file ->
          prerr_endline "End of scan";

      
;;
