(* OASIS_START *)
(* DO NOT EDIT (digest: 882a0b55652b4d8c13c85cf0a42221d5) *)
This is the README file for the camera-rescue distribution.

(C) 2010 OCamlCore SARL

Recover JPEG files from a crashed SD/MMC/CF camera memory card

This program searches for JPEG files into a dump of a memory card (a RAW
file). Once found, each files is saved in a different JPEG file.

This tool scans for JPEG markers inside the RAW. When a SOI (Start of Image)
marker is found, the tool scan the content to find a consistent EOI (End of
Image) marker.

It doesn't need to have a valid filesystem so it can handle most of the
crashed memory card. It recovers the image data and EXIF information.

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 

Home page: http://forge.ocamlcore.org/projects/camera-rescue/


(* OASIS_STOP *)
