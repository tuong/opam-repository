#ifndef ML_IRR_VIDEO_H
#define ML_IRR_VIDEO_H

#include "global.h"

S3DVertex Vertex_val(value);
value copy_vertex(S3DVertex);

SLight Light_val(value);
value copy_light(SLight);

#endif
