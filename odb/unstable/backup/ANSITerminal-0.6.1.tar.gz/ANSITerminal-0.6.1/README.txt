(* OASIS_START *)
(* DO NOT EDIT (digest: 3bbb7e659f28a81f5c4260a49933d1c0) *)
This is the README file for the ANSITerminal distribution.

Basic control of ANSI compliant terminals and the windows shell.

ANSITerminal is a module allowing to use the colors and cursor movements on
ANSI terminals. It also works on the windows shell (but this part is
currently work in progress).

See the files INSTALL.txt for building and installation instructions. 

Home page: https://forge.ocamlcore.org/projects/ansiterminal/


(* OASIS_STOP *)
