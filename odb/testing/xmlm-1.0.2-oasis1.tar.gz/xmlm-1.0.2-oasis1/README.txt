(* OASIS_START *)
(* DO NOT EDIT (digest: fc343d8b5294e86f0464159f9cc20a97) *)
This is the README file for the xmlm distribution.

An OCaml module for streaming XML processing.

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
