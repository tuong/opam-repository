(* OASIS_START *)
(* DO NOT EDIT (digest: 2bcb4ae8240dbda40732413810908573) *)
This is the README file for the cairo distribution.

Binding to Cairo, a Vector Graphics Library.

This is a binding to Cairo, a 2D graphics library with support for multiple
output devices.  Currently supported output targets include the X Window
System, Quartz, Win32, image buffers, PostScript, PDF, and SVG file output.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/cairo/


(* OASIS_STOP *)
