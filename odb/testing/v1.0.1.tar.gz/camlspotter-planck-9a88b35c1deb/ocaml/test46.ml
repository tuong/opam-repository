let ( / ) = concat
let ( -.- ) file ext = add_extension ext file
