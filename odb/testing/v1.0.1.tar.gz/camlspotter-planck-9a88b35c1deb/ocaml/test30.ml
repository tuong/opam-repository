let f = function Node(l, v, _) -> 1
