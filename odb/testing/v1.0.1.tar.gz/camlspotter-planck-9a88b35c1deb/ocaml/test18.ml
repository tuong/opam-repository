module Make (H : A.B) = struct
end
