(* OASIS_START *)
(* DO NOT EDIT (digest: ae53c5d2fcfc2334185181a4f70fa4ca) *)
This is the README file for the ocaml-hdf distribution.

Bindings for the HDF4 library

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
