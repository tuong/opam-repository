external succ : int -> int = "%succint"
external (~-) : int -> int = "%negint"
external pred : int -> int = "%predint"
