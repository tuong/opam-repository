(* Eq for functions *)
type t = int -> int deriving (Eq)
