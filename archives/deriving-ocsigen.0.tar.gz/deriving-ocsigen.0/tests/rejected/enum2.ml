(* Enum for sum types with arguments *)
type t = X of int | Y
    deriving (Enum)
