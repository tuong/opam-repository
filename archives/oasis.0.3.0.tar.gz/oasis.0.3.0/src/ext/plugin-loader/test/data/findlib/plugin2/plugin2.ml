let () =
  PluginloaderLib.registered_plugins :=
  "plugin2" :: !PluginloaderLib.registered_plugins
