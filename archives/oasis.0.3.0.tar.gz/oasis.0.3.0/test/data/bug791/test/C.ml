open B
