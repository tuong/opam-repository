(* OASIS_START *)
(* DO NOT EDIT (digest: 44c0c8491b9c7fe4d05d4680f9a16ff1) *)
This is the README file for the archimedes distribution.

Extensible 2D plotting library.

Archimedes is a high quality, platform-independent, extensible 2D plotting
library.  It provides dynamically loaded backends such as Graphics and Cairo.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/archimedes/


(* OASIS_STOP *)

Acknowledgments
---------------

This project was started in June 2009 thanks to financial support of
Jane Street Capital <http://www.janestcapital.com/>.  It was also
sponsored during the summer 2011 by the Faculty of Science of the
University of Mons.  We are very grateful to both organizations for
their support.
