(* OASIS_START *)
(* DO NOT EDIT (digest: 6876b4fb1fe9bdaaa019a51d103b31a8) *)
This is the README file for the cairo distribution.

Binding to Cairo, a Vector Graphics Library.

This is a binding to Cairo, a 2D graphics library with support for multiple
output devices.  Currently supported output targets include the X Window
System, Quartz, Win32, image buffers, PostScript, PDF, and SVG file output.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/archimedes/


(* OASIS_STOP *)
