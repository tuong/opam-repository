open Deferred

include Infix

let choice       = choice
let choose       = choose
let choose_ident = choose_ident
let never        = never
let return       = return
let upon         = upon
let whenever     = whenever
