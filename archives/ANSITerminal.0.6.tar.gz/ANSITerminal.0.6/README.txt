(* OASIS_START *)
(* DO NOT EDIT (digest: 8c7e5ac424e97ec6b536c609a1373c8f) *)
This is the README file for the ANSITerminal distribution.

Basic control of ANSI compliant terminals and the windows shell.

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
