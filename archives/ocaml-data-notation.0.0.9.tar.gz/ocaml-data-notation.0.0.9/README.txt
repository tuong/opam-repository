(* OASIS_START *)
(* DO NOT EDIT (digest: 4580838bd3518403dce6c41cd6248982) *)
This is the README file for the ocaml-data-notation distribution.

(C) 2009-2010 OCamlCore SARL

Store data using OCaml notation

This library uses `type_conv` to dump OCaml data structures using OCaml data
notation.

This kind of data dumping helps to write OCaml code generator, like OASIS.

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 

Home page: http://forge.ocamlcore.org/projects/odn


(* OASIS_STOP *)
