type 'a t = int
external to_int : _ t -> int = "%identity"

type +'a internal

