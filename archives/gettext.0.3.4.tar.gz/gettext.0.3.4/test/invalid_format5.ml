open TestGettext;;
open Printf;;

let () = 
  eprintf (fn_ "%d category" "%Ld categories" 1) 1
;;
