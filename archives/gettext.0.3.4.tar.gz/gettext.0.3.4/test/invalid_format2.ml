open TestGettext;;
open Printf;;

let () = 
  eprintf (f_ "%Ld") 2
;;
