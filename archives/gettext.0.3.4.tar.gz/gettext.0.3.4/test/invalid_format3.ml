open TestGettext;;
open Printf;;

let () = 
  eprintf (f_ "%s") 2
;;
