type t = { x : int; y : float }
