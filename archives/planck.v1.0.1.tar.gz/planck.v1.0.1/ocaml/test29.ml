let main () =
  if true
  then print_string "OK\n"
  else print_string "FAILED\n"

