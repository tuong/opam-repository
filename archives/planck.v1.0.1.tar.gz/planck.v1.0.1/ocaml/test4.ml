type t = Location.t = Foo
