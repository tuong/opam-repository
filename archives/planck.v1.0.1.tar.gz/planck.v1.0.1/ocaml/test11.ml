type t = (int * float) list
