let x = repeat := (int_of_float (10. *. (float !repeat) /. !t) + 1); ;;

