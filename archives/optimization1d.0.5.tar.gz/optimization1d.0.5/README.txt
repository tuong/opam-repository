(* OASIS_START *)
(* DO NOT EDIT (digest: 40e223e6dee4c492ecb78c1a108fa447) *)
This is the README file for the optimization1d distribution.

Find extrema of 1D functions.

Collection of functions to seek the minimum and maximum of functions float ->
float.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/optimization1d/


(* OASIS_STOP *)
