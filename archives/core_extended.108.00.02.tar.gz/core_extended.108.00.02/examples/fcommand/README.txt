
see http://internal.web/docs/html/programming/library-notes/command-guide.html

for more information on programming with Core_extended.Std.Command and friends

