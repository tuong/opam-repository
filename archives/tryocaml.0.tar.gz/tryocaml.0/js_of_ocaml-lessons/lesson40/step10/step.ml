
fun input output ->  find_in "xxxx" input


