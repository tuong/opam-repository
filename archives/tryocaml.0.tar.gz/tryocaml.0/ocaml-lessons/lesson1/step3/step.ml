fun input output ->
  find_in  "- : int = 32" output
