fun input _ ->
  find_in  "incr 42;;" input
