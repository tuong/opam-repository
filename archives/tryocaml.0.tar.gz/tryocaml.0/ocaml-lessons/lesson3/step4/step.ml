fun _ output ->
  find_in  "- : int = 16" output
