fun input output ->
  find_in  "- : char =" output
