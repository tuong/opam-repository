fun input output ->
  find_in  "val f : ('a * 'b) array list -> 'b =" output
