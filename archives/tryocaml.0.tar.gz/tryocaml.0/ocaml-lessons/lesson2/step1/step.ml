fun input output -> find_in "val y : int = 43" output
