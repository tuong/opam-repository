fun input output ->
  find_in "string_of_int" input && find_in "- : bool" output
