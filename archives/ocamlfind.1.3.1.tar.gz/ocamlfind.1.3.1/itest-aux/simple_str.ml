let _ = Str.regexp ".*" in

print_string "OK\n";;

