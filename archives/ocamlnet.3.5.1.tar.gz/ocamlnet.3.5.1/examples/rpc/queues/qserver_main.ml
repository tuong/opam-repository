(* $Id: qserver_main.ml 286 2006-04-29 16:21:42Z gerd $ *)

Qserver.main()
;;
