open Core.Std

let () =
  print_endline "This binary is only used to check what gets linked in by core"
