(* OASIS_START *)
(* DO NOT EDIT (digest: 2438aa63d961ac6fc2ae3b19c4d4b115) *)
This is the README file for the root1d distribution.

Find roots of 1D functions.

Collection of functions to seek roots of functions float -> float.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/root1d/


(* OASIS_STOP *)
